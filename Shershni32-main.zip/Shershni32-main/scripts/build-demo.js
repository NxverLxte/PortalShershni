#!/usr/bin/env node
/**
 * Собирает демонстрационную версию без сервера в dist/demo/.
 * Её можно выложить на любой статический хостинг (GitHub Pages и т. п.).
 * Открывать нужно через веб-сервер: ES-модули не работают с file://.
 *
 *   npm run build:demo
 *   npx serve dist/demo     (или любой другой статический сервер)
 */
import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from '../server/config.js';

const OUT = path.join(ROOT, 'dist', 'demo');

fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });
fs.cpSync(path.join(ROOT, 'public'), OUT, { recursive: true });
fs.cpSync(path.join(ROOT, 'core'), path.join(OUT, 'core'), { recursive: true });

const indexFile = path.join(OUT, 'index.html');
let html = fs.readFileSync(indexFile, 'utf8');
const mainScript = '<script type="module" src="js/main.js"></script>';
if (!html.includes(mainScript)) throw new Error('В public/index.html не найден тег подключения js/main.js');

html = html
  .replace('<title>Портал ШЕРШНЕЙ</title>', '<title>Портал ШЕРШНЕЙ — демо</title>')
  .replace('</head>', '  <link rel="stylesheet" href="demo/demo.css">\n</head>')
  .replace(mainScript, `<script type="module" src="demo/mock.js"></script>\n  ${mainScript}`);
fs.writeFileSync(indexFile, html);

// API-адреса в демо абсолютные (/api/...), но перехватываются mock.js, поэтому
// сайт работает в любой подпапке хостинга.
const count = (dir) => fs.readdirSync(dir, { withFileTypes: true }).reduce((n, e) => n + (e.isDirectory() ? count(path.join(dir, e.name)) : 1), 0);
console.log(`Демо собрано: ${path.relative(ROOT, OUT)} (${count(OUT)} файлов)`);
