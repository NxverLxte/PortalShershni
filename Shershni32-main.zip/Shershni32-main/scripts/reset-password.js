#!/usr/bin/env node
/**
 * Смена пароля из командной строки — на случай, если Президент забыл свой.
 * Остановите сервер перед запуском, иначе он перезапишет файл при следующем действии.
 *
 *   npm run reset-password -- <логин> <новый-пароль>
 */
import { loadConfig } from '../server/config.js';
import { FileStore } from '../server/storage.js';
import { hashPassword } from '../server/crypto.js';

const [login, password] = process.argv.slice(2);
if (!login || !password) {
  console.error('Использование: npm run reset-password -- <логин> <новый-пароль>');
  process.exit(1);
}
if (password.length < 6) {
  console.error('Пароль должен содержать не менее 6 символов');
  process.exit(1);
}

const store = new FileStore(loadConfig().dataFile);
const db = store.load();
const user = db.users.find((u) => u.login === login.toLowerCase());
if (!user) {
  console.error(`Пользователь с логином «${login}» не найден`);
  process.exit(1);
}
user.pw = hashPassword(password);
for (const [key, s] of Object.entries(db.sessions)) if (s.uid === user.id) delete db.sessions[key];
store.save(db);
console.log(`Пароль пользователя «${user.nick}» (${user.login}) изменён. Все его сеансы завершены.`);
