#!/usr/bin/env node
/**
 * Резервная копия файла данных в data/backups/. Хранятся последние 30 копий.
 *   npm run backup
 * Для ежедневного запуска добавьте команду в планировщик (cron на сервере).
 */
import fs from 'node:fs';
import path from 'node:path';
import { loadConfig } from '../server/config.js';

const KEEP = 30;
const { dataFile } = loadConfig();

if (!fs.existsSync(dataFile)) {
  console.error(`Файл данных не найден: ${dataFile}`);
  process.exit(1);
}

const dir = path.join(path.dirname(dataFile), 'backups');
fs.mkdirSync(dir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
const target = path.join(dir, `data-${stamp}.json`);
fs.copyFileSync(dataFile, target);
console.log(`Резервная копия сохранена: ${target}`);

const old = fs.readdirSync(dir).filter((f) => /^data-.*\.json$/.test(f)).sort().slice(0, -KEEP);
for (const f of old) fs.unlinkSync(path.join(dir, f));
if (old.length) console.log(`Удалено старых копий: ${old.length}`);
