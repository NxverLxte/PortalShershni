#!/usr/bin/env node
/** Проверка синтаксиса всех JS-файлов проекта (быстрая проверка перед коммитом). */
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { ROOT } from '../server/config.js';

const SKIP = new Set(['node_modules', 'dist', 'data', '.git']);
const files = [];
(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP.has(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p);
    else if (e.name.endsWith('.js')) files.push(p);
  }
})(ROOT);

let failed = 0;
for (const f of files) {
  const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
  if (r.status !== 0) {
    failed++;
    console.error(`✗ ${path.relative(ROOT, f)}\n${r.stderr}`);
  }
}
console.log(failed ? `Ошибок: ${failed} из ${files.length} файлов` : `Синтаксис в порядке: ${files.length} файлов`);
process.exit(failed ? 1 : 0);
