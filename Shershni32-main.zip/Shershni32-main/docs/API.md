# HTTP API

Все ответы приходят в JSON. Ошибки возвращаются как `{ "error": "Текст для пользователя" }` с соответствующим HTTP-кодом. POST-запросы принимаются только с `Content-Type: application/json`.

Авторизация работает через cookie `sid`: она HttpOnly, SameSite=Lax и выдаётся при входе.

## Адреса

| Метод | Адрес | Тело | Ответ |
|---|---|---|---|
| GET | `/api/health` | — | `{ ok, demo }` |
| GET | `/api/state` | — | состояние (см. ниже) |
| POST | `/api/register` | `{ login, password, nick, gender }` | `{ ok, first }`; `first: true` означает, что пользователь стал Президентом |
| POST | `/api/login` | `{ login, password }` | `{ ok }` + cookie |
| POST | `/api/logout` | `{}` | `{ ok }` |
| POST | `/api/act` | `{ type, ...параметры }` | новое состояние |

Ограничения частоты: вход и регистрация — 10 попыток за 10 минут с одного IP, действия — 120 в минуту на пользователя.

## Состояние (`/api/state`)

Гость получает:

```js
{ me: null, decrees: [...], laws: [...], officials: [{ id, nick, role }] }
```

Вошедший гражданин дополнительно получает:

```js
{
  me: { id, nick, login, gender, role, status, score, agent, since, perms: ['case.judge', ...] },
  citizens, bills, amendments, cases, candidates, elections, replog
}
```

Президенту, кроме того, приходит `accounts`: все учётные записи вместе с ожидающими одобрения.

У выборов поле `votes` наружу не отдаётся. Вместо него приходят `turnout` (явка), `myVote` (свой выбор) и `results`. `results` равно `null`, пока голосование не завершено.

## Действия (`/api/act`)

| type | Параметры | Кто может |
|---|---|---|
| `decree.add` | `kind, title, text` | Президент |
| `decree.delete` | `id` | Президент |
| `bill.add` | `title, note, text` | гражданин |
| `bill.stage` | `id, status` | Член Конгресса (new, review, passed, rejected); Президент — любой статус, включая signed и veto |
| `bill.conclusion` | `id, text` | Президент |
| `bill.delete` | `id` | Президент |
| `amendment.add` | `art, text, why?` | гражданин |
| `amendment.status` | `id, status` | Президент |
| `amendment.resolution` | `id, text` | Президент |
| `amendment.delete` | `id` | Президент |
| `case.add` | `defendant, cat, art?, text, demand` | гражданин |
| `case.status` | `id, status` | Министр юстиции, Президент |
| `case.decision` | `id, text` | Министр юстиции, Президент |
| `case.delete` | `id` | Президент |
| `candidate.apply` | `post, months, text` | гражданин (кроме агентов) |
| `candidate.review` | `id, status` | Министр юстиции (check, no); Президент (в т. ч. ok) |
| `candidate.delete` | `id` | Президент |
| `election.open` | `post, seats?` | Президент |
| `election.vote` | `eid, cid` | гражданин (кроме агентов), один раз |
| `election.close` | `eid` | Президент |
| `election.apply` | `eid` | Президент: победители получают должность |
| `election.delete` | `eid` | Президент |
| `reputation.change` | `uid, delta, reason` | Президент |
| `agent.assign` | `uid, reason` | Министр юстиции, Президент |
| `agent.remove` | `uid` | Президент |
| `user.status` | `uid, status` | Президент |
| `user.role` | `uid, role` | Президент |
| `user.password` | `uid, text` | Президент |
| `user.delete` | `uid` | Президент |
| `me.password` | `old, password` | любой вошедший |
| `spy.create` | `listId, spies` | гражданин (становится ведущим) |
| `spy.join` / `spy.leave` | `rid` | гражданин |
| `spy.settings` | `rid, listId, spies` | ведущий, между раундами |
| `spy.start` / `spy.reveal` | `rid` | ведущий |
| `spy.kick` | `rid, uid` | ведущий |
| `spy.close` | `rid` | ведущий или Президент |
| `wordlist.create` | `title, words` | Президент |
| `wordlist.add` | `id, words` (списком) | Президент |
| `wordlist.remove` | `id, word` | Президент |
| `wordlist.rename` | `id, text` | Президент |
| `wordlist.delete` | `id` | Президент |

Значения статусов и должностей перечислены в `core/constants.js`.
