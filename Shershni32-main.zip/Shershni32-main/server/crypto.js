/** Пароли (scrypt), случайные идентификаторы и токены сеансов. */
import crypto from 'node:crypto';

const KEYLEN = 64;

export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, KEYLEN).toString('hex');
  return `scrypt:${salt}:${hash}`;
}

/** Поддерживает и текущий формат "scrypt:соль:хеш", и формат первой версии "соль:хеш". */
export function verifyPassword(password, stored) {
  const parts = String(stored || '').split(':');
  const [salt, hash] = parts[0] === 'scrypt' ? parts.slice(1) : parts;
  if (!salt || !hash) return false;
  const expected = Buffer.from(hash, 'hex');
  const actual = crypto.scryptSync(password, salt, expected.length || KEYLEN);
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

export const randomId = () => crypto.randomBytes(8).toString('hex');
export const randomToken = () => crypto.randomBytes(32).toString('hex');
export const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
