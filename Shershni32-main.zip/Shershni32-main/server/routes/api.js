/**
 * HTTP API портала.
 *
 *   GET  /api/health    — проверка работоспособности
 *   GET  /api/state     — всё, что видит текущий посетитель
 *   POST /api/register  — заявление о приёме в гражданство
 *   POST /api/login     — вход
 *   POST /api/logout    — выход
 *   POST /api/act       — любое действие ядра: { type: 'decree.add', ... }
 *
 * Подробности: docs/API.md
 */
import { DomainError } from '../../core/errors.js';
import { readJson, sendJson, parseCookies, setCookie, clientIp, isHttps } from '../http.js';
import { createSession, destroySession, userBySession, pruneSessions } from '../sessions.js';
import { createLimiter } from '../ratelimit.js';

const COOKIE = 'sid';

export function createApiHandler(app) {
  const { core, config } = app;
  const authLimiter = createLimiter({ windowMs: 10 * 60e3, max: 10 });
  const actLimiter = createLimiter({ windowMs: 60e3, max: 120 });

  const currentUser = (req) => userBySession(app.db, parseCookies(req)[COOKIE]);

  return async function handle(req, res, pathname) {
    const me = currentUser(req);

    if (req.method === 'GET') {
      if (pathname === '/api/health') return sendJson(res, 200, { ok: true, demo: config.demo });
      if (pathname === '/api/state') return sendJson(res, 200, core.state(app.db, me));
      throw new DomainError('Не найдено', 404);
    }
    if (req.method !== 'POST') throw new DomainError('Метод не поддерживается', 405);

    const body = await readJson(req);
    const ip = clientIp(req, config.trustProxy);

    switch (pathname) {
      case '/api/register': {
        if (authLimiter.hit(ip)) throw new DomainError('Слишком много попыток. Повторите через 10 минут', 429);
        const { first } = app.transaction(() => core.register(app.db, body));
        if (first) app.log(`Первый зарегистрированный пользователь назначен Президентом: ${body.login}`);
        return sendJson(res, 200, { ok: true, first });
      }

      case '/api/login': {
        if (authLimiter.hit(ip)) throw new DomainError('Слишком много попыток. Повторите через 10 минут', 429);
        const user = core.authenticate(app.db, body.login, body.password);
        authLimiter.reset(ip);
        pruneSessions(app.db);
        const token = createSession(app.db, user.id, config.sessionDays);
        app.commit();
        setCookie(res, COOKIE, token, { maxAge: config.sessionDays * 86400, secure: isHttps(req, config) });
        return sendJson(res, 200, { ok: true });
      }

      case '/api/logout': {
        destroySession(app.db, parseCookies(req)[COOKIE]);
        app.commit();
        setCookie(res, COOKIE, '', { maxAge: 0, secure: isHttps(req, config) });
        return sendJson(res, 200, { ok: true });
      }

      case '/api/act': {
        if (!me) throw new DomainError('Требуется вход в личный кабинет', 401);
        if (actLimiter.hit(me.id)) throw new DomainError('Слишком много действий. Подождите минуту', 429);
        app.transaction(() => core.act(app.db, me, body));
        // После действия пользователь мог измениться (например, сменил пароль) — берём актуального
        return sendJson(res, 200, core.state(app.db, currentUser(req)));
      }

      default:
        throw new DomainError('Не найдено', 404);
    }
  };
}
