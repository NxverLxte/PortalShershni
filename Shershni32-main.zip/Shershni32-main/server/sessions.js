/**
 * Сеансы. В cookie лежит случайный токен, в базе — только его SHA-256,
 * поэтому утечка файла данных не даёт войти под чужой учётной записью.
 */
import { randomToken, sha256 } from './crypto.js';

const DAY = 864e5;

export function createSession(db, uid, days) {
  const token = randomToken();
  db.sessions[sha256(token)] = { uid, exp: Date.now() + days * DAY, created: Date.now() };
  return token;
}

/** Возвращает допущенного пользователя по токену или null. */
export function userBySession(db, token) {
  if (!token) return null;
  const s = db.sessions[sha256(token)];
  if (!s || s.exp < Date.now()) return null;
  const user = db.users.find((u) => u.id === s.uid);
  return user && user.status === 'approved' ? user : null;
}

export function destroySession(db, token) {
  if (token) delete db.sessions[sha256(token)];
}

export function pruneSessions(db) {
  const now = Date.now();
  for (const [key, s] of Object.entries(db.sessions)) if (s.exp < now) delete db.sessions[key];
}
