/** Раздача статических файлов с защитой от выхода за пределы папки и поддержкой 304. */
import fs from 'node:fs';
import path from 'node:path';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.woff2': 'font/woff2',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
};

/**
 * mounts: [{ prefix: '/core/', dir }, { prefix: '/', dir }] — первый подходящий префикс выигрывает.
 * Возвращает false, если файл не найден (тогда вызывающий отдаёт 404).
 */
export function createStatic(mounts) {
  return function serve(req, res, pathname) {
    const mount = mounts.find((m) => pathname.startsWith(m.prefix));
    if (!mount) return false;

    let rel;
    try {
      rel = decodeURIComponent(pathname.slice(mount.prefix.length));
    } catch {
      return false;
    }
    if (rel === '' || rel.endsWith('/')) rel += 'index.html';
    const file = path.resolve(mount.dir, rel);
    if (file !== mount.dir && !file.startsWith(mount.dir + path.sep)) return false;
    if (path.basename(file).startsWith('.')) return false;

    let stat;
    try {
      stat = fs.statSync(file);
    } catch {
      return false;
    }
    if (!stat.isFile()) return false;

    const etag = `W/"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
    const ext = path.extname(file).toLowerCase();
    const headers = {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      ETag: etag,
      'Cache-Control': ext === '.png' || ext === '.webp' || ext === '.jpg' || ext === '.woff2' ? 'public, max-age=86400' : 'no-cache',
    };
    if (req.headers['if-none-match'] === etag) {
      res.writeHead(304, headers);
      res.end();
      return true;
    }
    res.writeHead(200, { ...headers, 'Content-Length': stat.size });
    if (req.method === 'HEAD') res.end();
    else fs.createReadStream(file).pipe(res);
    return true;
  };
}
