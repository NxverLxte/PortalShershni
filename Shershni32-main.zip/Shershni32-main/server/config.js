/** Настройки сервера из переменных окружения и аргументов командной строки. */
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export function loadConfig(env = process.env, argv = process.argv) {
  const flag = (name) => argv.includes(`--${name}`);
  return {
    port: Number(env.PORT) || 3000,
    host: env.HOST || '0.0.0.0',
    dataFile: path.resolve(env.DATA_FILE || path.join(ROOT, 'data', 'data.json')),
    demo: flag('demo') || env.DEMO === '1',
    sessionDays: Number(env.SESSION_DAYS) || 30,
    /** Включайте, если сайт открывается по https (ставит флаг Secure на cookie). */
    secureCookies: env.SECURE_COOKIE === '1',
    /** Включайте, если перед сервером стоит nginx/Caddy/хостинг-прокси: тогда IP берётся из X-Forwarded-For. */
    trustProxy: env.TRUST_PROXY === '1',
    publicDir: path.join(ROOT, 'public'),
    coreDir: path.join(ROOT, 'core'),
    logRequests: env.LOG_REQUESTS === '1',
  };
}
