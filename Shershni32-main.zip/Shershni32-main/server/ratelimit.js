/** Ограничение частоты запросов: защита входа и регистрации от перебора. */
export function createLimiter({ windowMs = 10 * 60e3, max = 10 } = {}) {
  const hits = new Map();

  const sweep = setInterval(() => {
    const now = Date.now();
    for (const [key, list] of hits) {
      const fresh = list.filter((t) => now - t < windowMs);
      if (fresh.length) hits.set(key, fresh);
      else hits.delete(key);
    }
  }, windowMs);
  sweep.unref?.();

  return {
    /** Учитывает попытку; возвращает true, если лимит превышен. */
    hit(key) {
      const now = Date.now();
      const list = (hits.get(key) || []).filter((t) => now - t < windowMs);
      list.push(now);
      hits.set(key, list);
      return list.length > max;
    },
    reset(key) {
      hits.delete(key);
    },
  };
}
