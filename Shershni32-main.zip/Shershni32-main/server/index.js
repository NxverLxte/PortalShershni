#!/usr/bin/env node
/** Точка входа: `npm start` (рабочий режим) или `npm run demo` (демо-данные в памяти). */
import { loadConfig } from './config.js';
import { createApp } from './app.js';

const config = loadConfig();
let app;
try {
  app = createApp(config);
} catch (err) {
  console.error(err.message);
  process.exit(1);
}

app.server.listen(config.port, config.host, () => {
  const url = `http://localhost:${config.port}`;
  console.log(`Портал ШЕРШНЕЙ запущен: ${url}`);
  if (config.demo) {
    console.log('Демонстрационный режим: данные хранятся в памяти и сбрасываются при перезапуске.');
    console.log('Логины: prez, vasya, anya, dima, kolyan — пароль у всех: demo');
  } else {
    console.log(`Файл данных: ${config.dataFile}`);
    if (!app.db.users.length) console.log('Пользователей ещё нет. Первый зарегистрированный станет Президентом — зарегистрируйтесь сразу.');
  }
});

function shutdown(signal) {
  console.log(`\nПолучен ${signal}, сохраняю данные и завершаю работу...`);
  try {
    app.commit();
  } catch (err) {
    console.error('Не удалось сохранить данные:', err.message);
  }
  app.server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
