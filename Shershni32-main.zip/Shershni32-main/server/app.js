/**
 * Сборка приложения: хранилище + ядро + HTTP-обработчики.
 * createApp() не слушает порт — это делает index.js (и тесты).
 */
import http from 'node:http';
import { createCore } from '../core/index.js';
import { seedDemo } from '../core/demo.js';
import { DomainError } from '../core/errors.js';
import { FileStore, MemoryStore } from './storage.js';
import { hashPassword, verifyPassword, randomId } from './crypto.js';
import { applySecurityHeaders, sendError, sendJson } from './http.js';
import { createStatic } from './static.js';
import { createApiHandler } from './routes/api.js';

export function createApp(config, { store, log = console.log } = {}) {
  const core = createCore({ id: randomId, hash: hashPassword, verify: verifyPassword });

  if (!store) {
    store = config.demo
      ? new MemoryStore(seedDemo({ id: randomId, hash: hashPassword }))
      : new FileStore(config.dataFile);
  }

  const app = {
    config,
    core,
    store,
    log,
    db: store.load(),

    /** Сохраняет текущее состояние базы. */
    commit() {
      store.save(app.db);
    },

    /** Выполняет изменение целиком или не выполняет вовсе: при ошибке база откатывается. */
    transaction(fn) {
      const snapshot = structuredClone(app.db);
      try {
        const result = fn();
        app.commit();
        return result;
      } catch (err) {
        app.db = snapshot;
        throw err;
      }
    },
  };

  const api = createApiHandler(app);
  const serveStatic = createStatic([
    { prefix: '/core/', dir: config.coreDir },
    { prefix: '/', dir: config.publicDir },
  ]);

  app.server = http.createServer(async (req, res) => {
    const started = Date.now();
    applySecurityHeaders(res);
    let pathname;
    try {
      pathname = new URL(req.url, 'http://localhost').pathname;
    } catch {
      return sendJson(res, 400, { error: 'Некорректный адрес' });
    }

    try {
      if (pathname.startsWith('/api/')) {
        await api(req, res, pathname);
      } else if (req.method === 'GET' || req.method === 'HEAD') {
        if (!serveStatic(req, res, pathname)) {
          // Неизвестный адрес без расширения — отдаём приложение (навигация идёт по #хешу)
          if (!/\.[a-z0-9]+$/i.test(pathname) && serveStatic(req, res, '/')) return;
          res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
          res.end('Не найдено');
        }
      } else {
        sendJson(res, 405, { error: 'Метод не поддерживается' });
      }
    } catch (err) {
      if (!(err instanceof DomainError)) {
        log(`Ошибка при обработке ${req.method} ${pathname}:`, err);
        err = new DomainError('Внутренняя ошибка сервера', 500);
      }
      if (!res.headersSent) sendError(res, err);
      else res.end();
    } finally {
      if (config.logRequests) log(`${req.method} ${pathname} ${res.statusCode} ${Date.now() - started}мс`);
    }
  });

  return app;
}
