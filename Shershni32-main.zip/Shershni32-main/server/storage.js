/**
 * Хранилище базы. FileStore пишет JSON атомарно (через временный файл),
 * поэтому сбой во время записи не повредит данные.
 */
import fs from 'node:fs';
import path from 'node:path';
import { emptyDb, migrate } from '../core/schema.js';

export class FileStore {
  constructor(file) {
    this.file = file;
  }

  load() {
    let raw;
    try {
      raw = fs.readFileSync(this.file, 'utf8');
    } catch (err) {
      if (err.code === 'ENOENT') return emptyDb();
      throw err;
    }
    try {
      return migrate(JSON.parse(raw));
    } catch (err) {
      // Не затираем повреждённый файл пустой базой: пусть администратор разберётся.
      throw new Error(`Файл данных ${this.file} повреждён и не может быть прочитан: ${err.message}`);
    }
  }

  save(db) {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = `${this.file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(db, null, 1));
    fs.renameSync(tmp, this.file);
  }
}

/** Хранилище в памяти: для демо-режима и тестов. Ничего не пишет на диск. */
export class MemoryStore {
  constructor(db = emptyDb()) {
    this.db = db;
  }
  load() {
    return this.db;
  }
  save() {}
}
