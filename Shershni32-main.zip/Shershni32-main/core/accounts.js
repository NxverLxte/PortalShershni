/** Регистрация и проверка входа. Сеансы ведёт сервер (или демо-имитация). */
import { GENDERS, LIMITS, START_SCORE } from './constants.js';
import { fail } from './errors.js';
import { login as checkLogin, oneOf, password, text } from './validate.js';

/**
 * Первый зарегистрированный становится Президентом и допускается сразу.
 * Остальные ждут решения Президента в разделе «Администрирование».
 */
export function register(ctx, input) {
  const { db } = ctx;
  const login = checkLogin(input.login);
  if (db.users.some((u) => u.login === login)) fail('Этот логин уже занят');
  const nick = text(input.nick, { max: LIMITS.nick, label: 'Имя на сервере Discord' });
  if (db.users.some((u) => u.nick.toLowerCase() === nick.toLowerCase())) fail('Гражданин с таким именем уже зарегистрирован');

  const first = db.users.length === 0;
  const user = {
    id: ctx.id(),
    login,
    pw: ctx.hash(password(input.password)),
    nick,
    gender: oneOf(input.gender, GENDERS, 'Роль на сервере'),
    role: first ? 'president' : 'citizen',
    status: first ? 'approved' : 'pending',
    score: START_SCORE,
    agent: null,
    created: ctx.now,
  };
  db.users.push(user);
  return { user, first };
}

const STATUS_MESSAGES = {
  pending: 'Заявление о приёме в гражданство находится на рассмотрении',
  rejected: 'В приёме в гражданство отказано',
  blocked: 'Учётная запись заблокирована',
};

export function authenticate(ctx, login, pw) {
  const user = ctx.db.users.find((u) => u.login === String(login ?? '').trim().toLowerCase());
  if (!user || !ctx.verify(String(pw ?? ''), user.pw)) fail('Неверный логин или пароль', 401);
  if (user.status !== 'approved') fail(STATUS_MESSAGES[user.status] || 'Доступ ограничен', 403);
  return user;
}
