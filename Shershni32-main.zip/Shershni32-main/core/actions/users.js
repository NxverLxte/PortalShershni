/** Управление учётными записями (Президент) и собственным аккаунтом (любой гражданин). */
import { ASSIGNABLE_ROLES, USER_STATUS } from '../constants.js';
import { dropSessionsOf, ensure, findUser } from '../helpers.js';
import { fail } from '../errors.js';
import { oneOf, password } from '../validate.js';

function other(ctx, uid) {
  const u = findUser(ctx.db, uid);
  if (u.id === ctx.me.id) fail('Действие в отношении собственной учётной записи недоступно');
  return u;
}

export default {
  'user.status'(ctx, a) {
    ensure(ctx, 'users.manage');
    const u = other(ctx, a.uid);
    u.status = oneOf(a.status, USER_STATUS, 'Статус');
    if (u.status !== 'approved') dropSessionsOf(ctx.db, u.id);
  },

  'user.role'(ctx, a) {
    ensure(ctx, 'users.manage');
    const u = other(ctx, a.uid);
    const role = oneOf(a.role, ASSIGNABLE_ROLES, 'Должность');
    if (u.agent && role !== 'citizen') fail('Лицо, внесённое в реестр агентов дестабилизации, не вправе замещать государственные должности (ст. 8.1)');
    u.role = role;
  },

  'user.password'(ctx, a) {
    ensure(ctx, 'users.manage');
    const u = other(ctx, a.uid);
    u.pw = ctx.hash(password(a.text));
    dropSessionsOf(ctx.db, u.id);
  },

  'user.delete'(ctx, a) {
    ensure(ctx, 'users.manage');
    const u = other(ctx, a.uid);
    ctx.db.users = ctx.db.users.filter((x) => x.id !== u.id);
    dropSessionsOf(ctx.db, u.id);
  },

  'me.password'(ctx, a) {
    if (!ctx.verify(String(a.old ?? ''), ctx.me.pw)) fail('Действующий пароль указан неверно');
    ctx.me.pw = ctx.hash(password(a.password));
  },
};
