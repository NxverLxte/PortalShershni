/** Акты Президента: указы, распоряжения, официальные сообщения (ст. 40.2). */
import { ACT_KINDS, LIMITS } from '../constants.js';
import { ensure, nextNo, remove } from '../helpers.js';
import { oneOf, text } from '../validate.js';

export default {
  'decree.add'(ctx, a) {
    ensure(ctx, 'decree.manage');
    ctx.db.decrees.unshift({
      id: ctx.id(),
      no: nextNo(ctx.db, 'decrees'),
      kind: oneOf(a.kind, ACT_KINDS, 'Вид акта'),
      title: text(a.title, { max: LIMITS.title, label: 'Наименование' }),
      text: text(a.text, { max: LIMITS.longText, label: 'Текст акта' }),
      t: ctx.now,
    });
  },

  'decree.delete'(ctx, a) {
    ensure(ctx, 'decree.manage');
    remove(ctx.db, 'decrees', a.id);
  },
};
