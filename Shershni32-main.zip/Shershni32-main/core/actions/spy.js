/**
 * Игра «Шпион».
 *
 * Комнату создаёт любой гражданин и становится ведущим. Ведущий выбирает тему
 * и число шпионов и запускает раунд: всем игрокам выдаётся одно слово из темы,
 * шпионам — только отметка «Вы шпион». Обсуждение идёт голосом в Discord.
 * В конце раунда ведущий раскрывает слово и шпионов.
 *
 * Тайна ролей: каждый игрок получает только свою карточку (см. views.js → publicSpyRoom).
 */
import { LIMITS } from '../constants.js';
import { ensure, find, nextNo } from '../helpers.js';
import { fail, forbidden } from '../errors.js';
import { int, text } from '../validate.js';

export const SPY = Object.freeze({
  minPlayers: 3,
  maxPlayers: 20,
  maxSpies: 10,
  maxWords: 1000,
  maxWordLength: 60,
  maxLists: 50,
});

/* --- Вспомогательные --- */

const activeRoomOf = (db, uid) => db.spyRooms.find((r) => r.players.includes(uid));

function hostRoom(ctx, rid) {
  const room = find(ctx.db, 'spyRooms', rid, 'Комната');
  if (room.hostId !== ctx.me.id) forbidden();
  return room;
}

function list(ctx, id) {
  return find(ctx.db, 'wordlists', id, 'Тема');
}

/** Разбирает слова, введённые списком: по строкам, через запятую или точку с запятой. */
export function parseWords(input) {
  const seen = new Set();
  const out = [];
  for (const raw of String(input ?? '').split(/[\n,;]+/)) {
    const w = raw.trim().replace(/\s+/g, ' ');
    if (!w) continue;
    if (w.length > SPY.maxWordLength) fail(`Слово «${w.slice(0, 20)}…» длиннее ${SPY.maxWordLength} символов`);
    const key = w.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(w);
  }
  return out;
}

/** Случайная выборка k элементов (Фишер — Йейтс). */
function sample(items, k, random) {
  const a = [...items];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a.slice(0, k);
}

function settings(ctx, a) {
  const listId = list(ctx, a.listId).id;
  const spies = int(a.spies, { min: 1, max: SPY.maxSpies, label: 'Число шпионов' });
  return { listId, spies };
}

export default {
  /* --- Комнаты --- */

  'spy.create'(ctx, a) {
    if (activeRoomOf(ctx.db, ctx.me.id)) fail('Вы уже находитесь в игровой комнате');
    ctx.db.spyRooms.unshift({
      id: ctx.id(),
      no: nextNo(ctx.db, 'spyRooms'),
      hostId: ctx.me.id,
      ...settings(ctx, a),
      status: 'lobby',
      players: [ctx.me.id],
      round: null,
      rounds: 0,
      t: ctx.now,
    });
  },

  'spy.join'(ctx, a) {
    const room = find(ctx.db, 'spyRooms', a.rid, 'Комната');
    if (room.players.includes(ctx.me.id)) return;
    if (activeRoomOf(ctx.db, ctx.me.id)) fail('Вы уже находитесь в другой игровой комнате');
    if (room.status === 'playing') fail('Идёт раунд. Присоединиться можно после его завершения');
    if (room.players.length >= SPY.maxPlayers) fail(`В комнате не более ${SPY.maxPlayers} игроков`);
    room.players.push(ctx.me.id);
  },

  'spy.leave'(ctx, a) {
    const room = find(ctx.db, 'spyRooms', a.rid, 'Комната');
    room.players = room.players.filter((id) => id !== ctx.me.id);
    if (!room.players.length) {
      ctx.db.spyRooms = ctx.db.spyRooms.filter((r) => r.id !== room.id);
      return;
    }
    // Ведущий ушёл — ведущим становится следующий игрок
    if (room.hostId === ctx.me.id) room.hostId = room.players[0];
  },

  'spy.kick'(ctx, a) {
    const room = hostRoom(ctx, a.rid);
    if (a.uid === ctx.me.id) fail('Ведущий не может исключить себя. Покиньте комнату');
    room.players = room.players.filter((id) => id !== a.uid);
  },

  'spy.settings'(ctx, a) {
    const room = hostRoom(ctx, a.rid);
    if (room.status === 'playing') fail('Настройки меняются между раундами');
    Object.assign(room, settings(ctx, { listId: a.listId ?? room.listId, spies: a.spies ?? room.spies }));
  },

  'spy.start'(ctx, a) {
    const room = hostRoom(ctx, a.rid);
    if (room.status === 'playing') fail('Раунд уже идёт');
    const n = room.players.length;
    if (n < SPY.minPlayers) fail(`Для начала раунда нужно не менее ${SPY.minPlayers} игроков`);
    if (n - room.spies < 2) fail(`При ${n} игроках шпионов может быть не более ${n - 2}`);
    const words = list(ctx, room.listId).words;
    if (!words.length) fail('В выбранной теме нет слов');

    const random = ctx.random;
    let word = words[Math.floor(random() * words.length)];
    // Не повторяем слово предыдущего раунда, если есть выбор
    if (words.length > 1 && room.round?.word === word) word = words[(words.indexOf(word) + 1) % words.length];

    room.rounds += 1;
    room.status = 'playing';
    room.round = {
      no: room.rounds,
      word,
      listTitle: list(ctx, room.listId).title,
      spies: sample(room.players, room.spies, random),
      players: [...room.players],
      // Кто начинает задавать вопросы
      first: room.players[Math.floor(random() * n)],
      t: ctx.now,
    };
  },

  'spy.reveal'(ctx, a) {
    const room = hostRoom(ctx, a.rid);
    if (room.status !== 'playing') fail('Раунд не идёт');
    room.status = 'revealed';
    room.round.revealedAt = ctx.now;
  },

  'spy.close'(ctx, a) {
    const room = find(ctx.db, 'spyRooms', a.rid, 'Комната');
    if (room.hostId !== ctx.me.id) ensure(ctx, 'games.moderate');
    ctx.db.spyRooms = ctx.db.spyRooms.filter((r) => r.id !== room.id);
  },

  /* --- Темы (слова) --- */

  'wordlist.create'(ctx, a) {
    ensure(ctx, 'games.words');
    if (ctx.db.wordlists.length >= SPY.maxLists) fail(`Не более ${SPY.maxLists} тем`);
    const title = text(a.title, { max: LIMITS.title, label: 'Название темы' });
    if (ctx.db.wordlists.some((l) => l.title.toLowerCase() === title.toLowerCase())) fail('Тема с таким названием уже есть');
    const words = parseWords(a.words);
    if (words.length > SPY.maxWords) fail(`В теме не более ${SPY.maxWords} слов`);
    ctx.db.wordlists.push({ id: ctx.id(), title, words });
  },

  'wordlist.add'(ctx, a) {
    ensure(ctx, 'games.words');
    const l = list(ctx, a.id);
    const existing = new Set(l.words.map((w) => w.toLowerCase()));
    const fresh = parseWords(a.words).filter((w) => !existing.has(w.toLowerCase()));
    if (!fresh.length) fail('Новых слов не найдено: все уже есть в теме');
    if (l.words.length + fresh.length > SPY.maxWords) fail(`В теме не более ${SPY.maxWords} слов`);
    l.words.push(...fresh);
  },

  'wordlist.remove'(ctx, a) {
    ensure(ctx, 'games.words');
    const l = list(ctx, a.id);
    l.words = l.words.filter((w) => w !== a.word);
  },

  'wordlist.rename'(ctx, a) {
    ensure(ctx, 'games.words');
    list(ctx, a.id).title = text(a.text, { max: LIMITS.title, label: 'Название темы' });
  },

  'wordlist.delete'(ctx, a) {
    ensure(ctx, 'games.words');
    if (ctx.db.spyRooms.some((r) => r.listId === a.id)) fail('Тема используется в открытой комнате');
    ctx.db.wordlists = ctx.db.wordlists.filter((l) => l.id !== a.id);
  },
};
