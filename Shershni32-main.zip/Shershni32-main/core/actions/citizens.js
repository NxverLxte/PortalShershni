/** Репутация граждан и реестр агентов дестабилизации сообщества (ст. 8.1). */
import { AGENT_THRESHOLD, LIMITS } from '../constants.js';
import { ensure, findUser } from '../helpers.js';
import { fail } from '../errors.js';
import { int, text } from '../validate.js';

const REPLOG_MAX = 1000;

export default {
  'reputation.change'(ctx, a) {
    ensure(ctx, 'reputation.manage');
    const u = findUser(ctx.db, a.uid);
    const delta = int(a.delta, { min: -LIMITS.repDelta, max: LIMITS.repDelta, label: 'Изменение' });
    if (delta === 0) fail('Изменение не может быть равно нулю');
    u.score = (u.score || 0) + delta;
    ctx.db.replog.unshift({
      id: ctx.id(),
      uid: u.id,
      nick: u.nick,
      delta,
      reason: text(a.reason, { max: LIMITS.shortText, label: 'Основание' }),
      by: ctx.me.nick,
      t: ctx.now,
    });
    ctx.db.replog.length = Math.min(ctx.db.replog.length, REPLOG_MAX);

    // Репутация 0 и ниже — автоматическое внесение в реестр агентов (решение Президента).
    // Снимается статус по-прежнему только решением Президента.
    if (u.score <= AGENT_THRESHOLD && !u.agent && u.role !== 'president') {
      u.agent = { reason: `Снижение репутации до ${u.score} (внесено автоматически)`, t: ctx.now, by: 'Портал', auto: true };
      u.role = 'citizen'; // агент не вправе замещать государственные должности (ст. 8.1)
    }
  },

  'agent.assign'(ctx, a) {
    ensure(ctx, 'agent.assign');
    const u = findUser(ctx.db, a.uid);
    if (u.role === 'president') fail('Статус не может быть присвоен Президенту');
    if (u.agent) fail('Гражданин уже внесён в реестр');
    u.agent = { reason: text(a.reason, { max: LIMITS.reason, label: 'Основание' }), t: ctx.now, by: ctx.me.nick };
    // Агент не вправе замещать государственные должности (ст. 8.1)
    u.role = 'citizen';
  },

  'agent.remove'(ctx, a) {
    ensure(ctx, 'agent.remove');
    findUser(ctx.db, a.uid).agent = null;
  },
};
