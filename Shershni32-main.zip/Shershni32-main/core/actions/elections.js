/**
 * Кандидаты и выборы (ст. 7.2, 8.1, 19–20.2).
 * Голосование тайное: в базе хранится выбор каждого гражданина, но наружу
 * отдаются только явка и, после завершения, итоговые числа (см. views.js).
 */
import { CANDIDATE_STATUS, LIMITS, POSTS } from '../constants.js';
import { ensure, find, remove } from '../helpers.js';
import { fail } from '../errors.js';
import { int, oneOf, text } from '../validate.js';
import { publicElection } from '../views.js';

export default {
  'candidate.apply'(ctx, a) {
    const { db, me } = ctx;
    if (me.agent) fail('Лицо, внесённое в реестр агентов дестабилизации, не вправе выдвигаться (ст. 8.1)');
    const post = oneOf(a.post, POSTS, 'Должность');
    if (db.candidates.some((c) => c.uid === me.id && c.post === post && c.status === 'check')) {
      fail('Ваше заявление на эту должность уже находится на проверке');
    }
    db.candidates.unshift({
      id: ctx.id(),
      uid: me.id,
      who: me.nick,
      post,
      months: int(a.months, { min: 0, max: LIMITS.months, label: 'Стаж' }),
      text: text(a.text, { max: LIMITS.text, label: 'Предвыборная программа' }),
      status: 'check',
      t: ctx.now,
    });
  },

  'candidate.review'(ctx, a) {
    ensure(ctx, 'candidate.check');
    const c = find(ctx.db, 'candidates', a.id, 'Заявление');
    const status = oneOf(a.status, CANDIDATE_STATUS, 'Статус');
    if (status === 'ok') ensure(ctx, 'candidate.approve'); // регистрацию утверждает Президент (ст. 20.1)
    c.status = status;
  },

  'candidate.delete'(ctx, a) {
    ensure(ctx, 'candidate.delete');
    remove(ctx.db, 'candidates', a.id);
  },

  'election.open'(ctx, a) {
    ensure(ctx, 'elections.manage');
    const { db } = ctx;
    const post = oneOf(a.post, POSTS, 'Должность');
    if (db.elections.some((e) => e.post === post && e.status === 'open')) fail('Выборы на эту должность уже проводятся');
    const seats = post === 'congress' ? int(a.seats, { min: 1, max: LIMITS.seats, label: 'Число мандатов' }) : 1;

    const seen = new Set();
    const candidates = db.candidates
      .filter((c) => c.post === post && c.status === 'ok')
      .map((c) => db.users.find((u) => u.id === c.uid))
      .filter((u) => u && u.status === 'approved' && !u.agent && !seen.has(u.id) && seen.add(u.id))
      .map((u) => ({ id: u.id, nick: u.nick }));
    if (!candidates.length) fail('Нет зарегистрированных кандидатов на эту должность');

    db.elections.unshift({ id: ctx.id(), post, seats, status: 'open', t: ctx.now, candidates, votes: {}, winners: [] });
  },

  'election.vote'(ctx, a) {
    const { me } = ctx;
    const e = find(ctx.db, 'elections', a.eid, 'Выборы');
    if (e.status !== 'open') fail('Голосование завершено');
    if (me.agent) fail('Лицо, внесённое в реестр агентов дестабилизации, не участвует в голосовании (ст. 8.1)');
    if (e.votes[me.id]) fail('Вы уже проголосовали');
    if (!e.candidates.some((c) => c.id === a.cid)) fail('Выберите кандидата');
    e.votes[me.id] = a.cid;
  },

  'election.close'(ctx, a) {
    ensure(ctx, 'elections.manage');
    const e = find(ctx.db, 'elections', a.eid, 'Выборы');
    if (e.status !== 'open') fail('Голосование уже завершено');
    e.status = 'closed';
    e.closedAt = ctx.now;
  },

  /** Утверждает итоги: кандидаты с наибольшим числом голосов получают должность. */
  'election.apply'(ctx, a) {
    ensure(ctx, 'elections.manage');
    const e = find(ctx.db, 'elections', a.eid, 'Выборы');
    if (e.status !== 'closed') fail('Сначала завершите голосование');
    if (e.applied) fail('Итоги уже утверждены');
    const { results } = publicElection(e, ctx.me);
    const winners = [...e.candidates]
      .filter((c) => results[c.id] > 0)
      .sort((x, y) => results[y.id] - results[x.id])
      .slice(0, e.seats);
    for (const w of winners) {
      const u = ctx.db.users.find((x) => x.id === w.id);
      if (u && u.role !== 'president' && !u.agent) u.role = e.post;
    }
    e.applied = true;
    e.winners = winners.map((w) => w.id);
  },

  'election.delete'(ctx, a) {
    ensure(ctx, 'elections.manage');
    remove(ctx.db, 'elections', a.eid);
  },
};
