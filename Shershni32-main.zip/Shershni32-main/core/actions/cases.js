/** Судебные дела. Правосудие осуществляет Министр юстиции (ст. 33). */
import { CASE_CATEGORIES, CASE_STATUS, LIMITS } from '../constants.js';
import { ensure, find, findUser, nextNo, remove } from '../helpers.js';
import { fail } from '../errors.js';
import { oneOf, optional, text } from '../validate.js';

export default {
  'case.add'(ctx, a) {
    const defendant = findUser(ctx.db, a.defendant);
    if (defendant.status !== 'approved') fail('Ответчик не является гражданином');
    if (defendant.id === ctx.me.id) fail('Нельзя подать иск к самому себе');
    ctx.db.cases.unshift({
      id: ctx.id(),
      no: nextNo(ctx.db, 'cases'),
      uid: ctx.me.id,
      who: ctx.me.nick,
      vsId: defendant.id,
      vs: defendant.nick,
      cat: oneOf(a.cat, CASE_CATEGORIES, 'Категория спора'),
      art: optional(a.art, LIMITS.article, 'Нарушенная норма'),
      text: text(a.text, { max: LIMITS.text, label: 'Обстоятельства дела' }),
      demand: text(a.demand, { max: LIMITS.text, label: 'Исковые требования' }),
      status: 'new',
      t: ctx.now,
    });
  },

  'case.status'(ctx, a) {
    ensure(ctx, 'case.judge');
    find(ctx.db, 'cases', a.id, 'Дело').status = oneOf(a.status, CASE_STATUS, 'Статус');
  },

  'case.decision'(ctx, a) {
    ensure(ctx, 'case.judge');
    const c = find(ctx.db, 'cases', a.id, 'Дело');
    c.res = optional(a.text, LIMITS.text, 'Решение суда');
    if (c.res && c.status !== 'closed') c.status = 'decided';
  },

  'case.delete'(ctx, a) {
    ensure(ctx, 'case.delete');
    remove(ctx.db, 'cases', a.id);
  },
};
