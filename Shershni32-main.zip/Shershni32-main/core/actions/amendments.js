/** Предложения поправок к Конституции. Вносит поправки Президент (ст. 39). */
import { AMENDMENT_STATUS, LIMITS } from '../constants.js';
import { ensure, find, nextNo, remove } from '../helpers.js';
import { oneOf, optional, text } from '../validate.js';

export default {
  'amendment.add'(ctx, a) {
    ctx.db.amendments.unshift({
      id: ctx.id(),
      no: nextNo(ctx.db, 'amendments'),
      uid: ctx.me.id,
      who: ctx.me.nick,
      art: text(a.art, { max: LIMITS.article, label: 'Статья' }),
      text: text(a.text, { max: LIMITS.text, label: 'Предлагаемая редакция' }),
      why: optional(a.why, LIMITS.text, 'Обоснование'),
      status: 'new',
      t: ctx.now,
    });
  },

  'amendment.status'(ctx, a) {
    ensure(ctx, 'amendment.review');
    find(ctx.db, 'amendments', a.id, 'Предложение').status = oneOf(a.status, AMENDMENT_STATUS, 'Статус');
  },

  'amendment.resolution'(ctx, a) {
    ensure(ctx, 'amendment.review');
    find(ctx.db, 'amendments', a.id, 'Предложение').res = optional(a.text, LIMITS.text, 'Резолюция');
  },

  'amendment.delete'(ctx, a) {
    ensure(ctx, 'amendment.review');
    remove(ctx.db, 'amendments', a.id);
  },
};
