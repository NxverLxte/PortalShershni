/**
 * Законопроекты. Внести может любой гражданин; стадии рассмотрения ведут
 * члены Конгресса; подписание и вето — исключительно Президент (ст. 12.4, 35).
 */
import { BILL_STATUS, BILL_CONGRESS_STATUSES, LIMITS } from '../constants.js';
import { can } from '../permissions.js';
import { ensure, find, nextNo, remove } from '../helpers.js';
import { forbidden } from '../errors.js';
import { oneOf, optional, text } from '../validate.js';

export default {
  'bill.add'(ctx, a) {
    ctx.db.bills.unshift({
      id: ctx.id(),
      no: nextNo(ctx.db, 'bills'),
      uid: ctx.me.id,
      who: ctx.me.nick,
      title: text(a.title, { max: LIMITS.title, label: 'Наименование законопроекта' }),
      note: text(a.note, { max: LIMITS.text, label: 'Пояснительная записка' }),
      text: text(a.text, { max: LIMITS.longText, label: 'Текст законопроекта' }),
      status: 'new',
      t: ctx.now,
    });
  },

  'bill.stage'(ctx, a) {
    const bill = find(ctx.db, 'bills', a.id, 'Законопроект');
    const status = oneOf(a.status, BILL_STATUS, 'Стадия');
    const allowed = can(ctx.me, 'bill.sign') || (can(ctx.me, 'bill.stage') && BILL_CONGRESS_STATUSES.includes(status));
    if (!allowed) forbidden();
    bill.status = status;
    if (status === 'signed') bill.signedAt = ctx.now;
    else delete bill.signedAt;
  },

  'bill.conclusion'(ctx, a) {
    ensure(ctx, 'bill.sign');
    find(ctx.db, 'bills', a.id, 'Законопроект').res = optional(a.text, LIMITS.text, 'Заключение');
  },

  'bill.delete'(ctx, a) {
    ensure(ctx, 'bill.manage');
    remove(ctx.db, 'bills', a.id);
  },
};
