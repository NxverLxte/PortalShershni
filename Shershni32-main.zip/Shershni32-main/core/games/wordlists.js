/**
 * Темы для игры «Шпион», записываемые в новую базу.
 * После этого Президент правит их на портале: добавляет слова списком,
 * удаляет лишние, создаёт новые темы.
 */

const split = (text) => text.split('\n').map((s) => s.trim()).filter(Boolean);

export const DEFAULT_WORDLISTS = [
  {
    id: 'places',
    title: 'Места',
    words: split(`
Больница
Школа
Аэропорт
Пляж
Ресторан
Кинотеатр
Банк
Полицейский участок
Супермаркет
Цирк
Космическая станция
Подводная лодка
Пиратский корабль
Поезд
Самолёт
Отель
Университет
Тюрьма
Музей
Зоопарк
Библиотека
Казино
Стадион
Театр
Военная база
Ночной клуб
Спортзал
Спа-салон
Посольство
Автосервис
Ферма
Полярная станция
Свадьба
Кафе
Парикмахерская
Пожарная часть
Почта
Метро
Рынок
Стройка
Шахта
Маяк
Аквапарк
Парк развлечений
Пиццерия
Офис
Детский лагерь
Баня
Каток
Вокзал
Морской порт
Кладбище
Заправка
Ветеринарная клиника
Компьютерный клуб`),
  },
  {
    id: 'objects',
    title: 'Предметы',
    words: split(`
Телефон
Зонт
Ключи
Часы
Холодильник
Подушка
Чайник
Ноутбук
Зеркало
Расчёска
Велосипед
Гитара
Рюкзак
Кошелёк
Очки
Ножницы
Карандаш
Свеча
Лампа
Утюг
Пылесос
Микроволновка
Наушники
Кружка
Вилка
Сковородка
Диван
Шкаф
Ковёр
Телевизор
Пульт
Зубная щётка
Полотенце
Мыло
Фонарик
Батарейка
Кроссовки
Шапка
Перчатки
Шарф
Чемодан
Книга
Мяч
Скейтборд
Молоток
Отвёртка
Лестница
Палатка
Глобус
Калькулятор`),
  },
  {
    id: 'dota-heroes',
    title: 'Герои Dota 2',
    words: split(`
Abaddon
Alchemist
Ancient Apparition
Anti-Mage
Arc Warden
Axe
Bane
Batrider
Beastmaster
Bloodseeker
Bounty Hunter
Brewmaster
Bristleback
Broodmother
Centaur Warrunner
Chaos Knight
Chen
Clinkz
Clockwerk
Crystal Maiden
Dark Seer
Dark Willow
Dawnbreaker
Dazzle
Death Prophet
Disruptor
Doom
Dragon Knight
Drow Ranger
Earth Spirit
Earthshaker
Elder Titan
Ember Spirit
Enchantress
Enigma
Faceless Void
Grimstroke
Gyrocopter
Hoodwink
Huskar
Invoker
Io
Jakiro
Juggernaut
Keeper of the Light
Kez
Kunkka
Legion Commander
Leshrac
Lich
Lifestealer
Lina
Lion
Lone Druid
Luna
Lycan
Magnus
Marci
Mars
Medusa
Meepo
Mirana
Monkey King
Morphling
Muerta
Naga Siren
Nature's Prophet
Necrophos
Night Stalker
Nyx Assassin
Ogre Magi
Omniknight
Oracle
Outworld Destroyer
Pangolier
Phantom Assassin
Phantom Lancer
Phoenix
Primal Beast
Puck
Pudge
Pugna
Queen of Pain
Razor
Riki
Ringmaster
Rubick
Sand King
Shadow Demon
Shadow Fiend
Shadow Shaman
Silencer
Skywrath Mage
Slardar
Slark
Snapfire
Sniper
Spectre
Spirit Breaker
Storm Spirit
Sven
Techies
Templar Assassin
Terrorblade
Tidehunter
Timbersaw
Tinker
Tiny
Treant Protector
Troll Warlord
Tusk
Underlord
Undying
Ursa
Vengeful Spirit
Venomancer
Viper
Visage
Void Spirit
Warlock
Weaver
Windranger
Winter Wyvern
Witch Doctor
Wraith King
Zeus`),
  },
  {
    id: 'dota-items',
    title: 'Предметы Dota 2',
    words: split(`
Blink Dagger
Black King Bar
Aghanim's Scepter
Aghanim's Shard
Divine Rapier
Butterfly
Daedalus
Desolator
Monkey King Bar
Abyssal Blade
Skull Basher
Battle Fury
Manta Style
Radiance
Heart of Tarrasque
Assault Cuirass
Shiva's Guard
Linken's Sphere
Lotus Orb
Blade Mail
Eul's Scepter of Divinity
Force Staff
Hurricane Pike
Glimmer Cape
Scythe of Vyse
Orchid Malevolence
Bloodthorn
Nullifier
Ethereal Blade
Dagon
Refresher Orb
Octarine Core
Satanic
Mjollnir
Maelstrom
Diffusal Blade
Eye of Skadi
Sange and Yasha
Kaya
Silver Edge
Shadow Blade
Hand of Midas
Boots of Travel
Power Treads
Phase Boots
Arcane Boots
Tranquil Boots
Guardian Greaves
Mekansm
Pipe of Insight
Vladmir's Offering
Crimson Guard
Solar Crest
Spirit Vessel
Magic Wand
Bottle
Observer Ward
Sentry Ward
Smoke of Deceit
Dust of Appearance
Tango
Healing Salve
Clarity
Town Portal Scroll
Aether Lens
Gleipnir
Wind Waker
Bloodstone
Overwhelming Blink
Swift Blink
Arcane Blink
Heaven's Halberd
Echo Sabre
Armlet of Mordiggian
Mask of Madness
Helm of the Overlord
Vanguard
Soul Ring
Holy Locket
Veil of Discord
Rod of Atos
Moon Shard
Gem of True Sight
Aegis of the Immortal
Aeon Disk`),
  },
];

/** Глубокая копия тем для записи в новую базу. */
export const defaultWordlists = () => DEFAULT_WORDLISTS.map((l) => ({ ...l, words: [...l.words] }));
