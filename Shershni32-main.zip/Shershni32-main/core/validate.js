import { fail } from './errors.js';

/** Обязательная строка: обрезает пробелы и проверяет длину. */
export function text(value, { max, min = 1, label = 'Поле' } = {}) {
  const v = String(value ?? '').trim();
  if (v.length < min) fail(min === 1 ? `${label}: поле обязательно для заполнения` : `${label}: не менее ${min} символов`);
  if (max && v.length > max) fail(`${label}: не более ${max} символов`);
  return v;
}

/** Необязательная строка: пустое значение допустимо. */
export const optional = (value, max, label) => text(value, { max, min: 0, label });

/** Значение из перечня: массива или ключей объекта. */
export function oneOf(value, list, label = 'Значение') {
  const keys = Array.isArray(list) ? list : Object.keys(list);
  if (!keys.includes(value)) fail(`${label}: недопустимое значение`);
  return value;
}

/** Целое число в диапазоне. */
export function int(value, { min, max, label = 'Число' }) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < min || n > max) fail(`${label}: целое число от ${min} до ${max}`);
  return n;
}

export const LOGIN_RE = /^[a-z0-9_.-]{3,32}$/;

export function login(value) {
  const v = String(value ?? '').trim().toLowerCase();
  if (!LOGIN_RE.test(v)) fail('Логин: от 3 до 32 символов — латинские буквы, цифры, знаки _ . -');
  return v;
}

/** Пароль не обрезается: пробелы по краям — часть пароля. */
export function password(value) {
  const v = String(value ?? '');
  if (v.length < 6) fail('Пароль: не менее 6 символов');
  if (v.length > 100) fail('Пароль: не более 100 символов');
  return v;
}
