/**
 * Справочники ШЕРШНЕЙ.
 * Модуль общий для сервера и браузера: без зависимостей от Node.js.
 */

/** Должности. Ключ хранится в учётной записи, значение показывается на сайте. */
export const ROLES = Object.freeze({
  president: 'Президент',
  congress: 'Член Конгресса',
  minjust: 'Министр юстиции',
  minob: 'Министр обороны',
  minfin: 'Министр финансов',
  mid: 'Министр иностранных дел',
  mvd: 'Министр внутренних дел',
  citizen: 'Гражданин',
});

/** Должности, на которые Президент может назначить (свою передать нельзя). */
export const ASSIGNABLE_ROLES = Object.freeze(Object.keys(ROLES).filter((r) => r !== 'president'));

/** Роль на Discord-сервере, подтверждающая гражданство (ст. 5). */
export const GENDERS = Object.freeze(['Шершень', 'Шершиня']);

export const USER_STATUS = Object.freeze({
  pending: 'На рассмотрении',
  approved: 'Допущен',
  rejected: 'Отказано',
  blocked: 'Заблокирован',
});

export const ACT_KINDS = Object.freeze(['Указ', 'Распоряжение', 'Официальное сообщение']);

export const AMENDMENT_STATUS = Object.freeze({
  new: 'Зарегистрировано',
  review: 'На рассмотрении Президента',
  accepted: 'Внесено в Конституцию',
  rejected: 'Отклонено',
});

export const CASE_STATUS = Object.freeze({
  new: 'Принято к производству',
  hearing: 'Судебное разбирательство',
  decided: 'Решение вынесено',
  closed: 'Производство прекращено',
});

export const CASE_CATEGORIES = Object.freeze([
  'Гражданско-правовой спор',
  'Нарушение Конституции',
  'Оспаривание решения должностного лица',
  'Обжалование статуса агента дестабилизации',
  'Иное',
]);

export const BILL_STATUS = Object.freeze({
  new: 'Внесён',
  review: 'На рассмотрении Конгресса',
  passed: 'Принят Конгрессом',
  signed: 'Подписан Президентом',
  veto: 'Отклонён Президентом',
  rejected: 'Отклонён',
});

/** Последовательность стадий законопроекта для отображения хода рассмотрения. */
export const BILL_STAGES = Object.freeze(['new', 'review', 'passed', 'signed']);

/** Стадии, которые вправе устанавливать члены Конгресса. Подпись и вето — только Президент (ст. 12.4, 35). */
export const BILL_CONGRESS_STATUSES = Object.freeze(['new', 'review', 'passed', 'rejected']);

export const CANDIDATE_STATUS = Object.freeze({
  check: 'Проверка Министерством юстиции',
  ok: 'Кандидат зарегистрирован',
  no: 'Отказано в регистрации',
});

/** Выборные должности (ст. 7.2, 19–20.2). */
export const POSTS = Object.freeze({
  congress: 'Член Конгресса',
  minjust: 'Министр юстиции',
  minob: 'Министр обороны',
});

/** Минимальный стаж кандидата в Конгресс, месяцев (ст. 19). */
export const CONGRESS_MIN_MONTHS = 18;

/**
 * Звания по репутации, от высшего к низшему:
 *   от 1000 — почётный шершень; 300–999 — шершень; 1–299 — ненадёжный шершень; 0 и ниже — агент.
 */
export const RANKS = Object.freeze([
  { min: 1000, title: 'Почётный шершень' },
  { min: 300, title: 'Шершень' },
  { min: 1, title: 'Ненадёжный шершень' },
  { min: -Infinity, title: 'Агент' },
]);

/** Репутация нового гражданина. */
export const START_SCORE = 500;

/** При снижении репутации до этого значения гражданин автоматически вносится в реестр агентов (ст. 8.1). */
export const AGENT_THRESHOLD = 0;

export const rankOf = (score = 0) => RANKS.find((r) => score >= r.min).title;

/** Ограничения длины полей. */
export const LIMITS = Object.freeze({
  nick: 40,
  title: 200,
  article: 40,
  shortText: 200,
  text: 4000,
  longText: 12000,
  reason: 1000,
  repDelta: 5000,
  seats: 50,
  months: 600,
});
