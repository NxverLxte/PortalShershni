/**
 * Представления данных для клиента. Здесь решается, кто что видит:
 * пароли, сеансы и тайна голосования наружу не попадают никогда.
 */
import { permissionsOf, can } from './permissions.js';

export function publicUser(u, full = false) {
  const out = {
    id: u.id,
    nick: u.nick,
    gender: u.gender,
    role: u.role,
    score: u.score || 0,
    agent: u.agent || null,
    since: u.created,
  };
  if (full) Object.assign(out, { login: u.login, status: u.status });
  return out;
}

/** Выборы: голоса отдельных граждан не раскрываются, итоги — только после завершения. */
export function publicElection(e, me) {
  const counts = Object.fromEntries(e.candidates.map((c) => [c.id, 0]));
  for (const choice of Object.values(e.votes)) if (choice in counts) counts[choice] += 1;
  return {
    id: e.id,
    post: e.post,
    seats: e.seats,
    status: e.status,
    applied: Boolean(e.applied),
    t: e.t,
    closedAt: e.closedAt || null,
    candidates: e.candidates,
    turnout: Object.keys(e.votes).length,
    myVote: me ? e.votes[me.id] || null : null,
    results: e.status === 'closed' ? counts : null,
    winners: e.winners || [],
  };
}

/**
 * Комната «Шпиона». Слово и состав шпионов видит только тот, кому они положены:
 * игрок раунда — свою карточку; все — итог после раскрытия.
 */
export function publicSpyRoom(room, me, db) {
  const nick = (id) => db.users.find((u) => u.id === id)?.nick || 'Выбывший участник';
  const list = db.wordlists.find((l) => l.id === room.listId);
  const r = room.round;
  let round = null;
  if (r) {
    const inRound = me && r.players.includes(me.id);
    round = {
      no: r.no,
      t: r.t,
      listTitle: r.listTitle,
      players: r.players.length,
      first: room.status === 'playing' ? nick(r.first) : null,
      card: inRound ? (r.spies.includes(me.id) ? { spy: true } : { word: r.word }) : null,
      reveal: room.status === 'revealed' ? { word: r.word, spies: r.spies.map(nick) } : null,
    };
  }
  return {
    id: room.id,
    no: room.no,
    hostId: room.hostId,
    host: nick(room.hostId),
    listId: room.listId,
    listTitle: list?.title || '—',
    spies: room.spies,
    status: room.status,
    players: room.players.map((id) => ({ id, nick: nick(id) })),
    rounds: room.rounds,
    round,
    t: room.t,
  };
}

export function buildState(db, me) {
  const approved = db.users.filter((u) => u.status === 'approved');
  const state = {
    me: me ? { ...publicUser(me, true), perms: permissionsOf(me) } : null,
    decrees: db.decrees,
    laws: db.bills.filter((b) => b.status === 'signed'),
    officials: approved.filter((u) => u.role !== 'citizen').map((u) => ({ id: u.id, nick: u.nick, role: u.role })),
  };
  if (!me) return state;

  Object.assign(state, {
    citizens: approved.map((u) => publicUser(u)),
    bills: db.bills,
    amendments: db.amendments,
    cases: db.cases,
    candidates: db.candidates,
    elections: db.elections.map((e) => publicElection(e, me)),
    replog: db.replog.slice(0, 100),
  });
  state.spy = {
    rooms: db.spyRooms.map((r) => publicSpyRoom(r, me, db)),
    // Слова тем видит только тот, кто их редактирует: остальным — название и количество
    lists: db.wordlists.map((l) => ({ id: l.id, title: l.title, count: l.words.length, ...(can(me, 'games.words') ? { words: l.words } : {}) })),
  };
  if (can(me, 'users.manage')) state.accounts = db.users.map((u) => publicUser(u, true));
  return state;
}
