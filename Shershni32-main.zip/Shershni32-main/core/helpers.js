import { can } from './permissions.js';
import { forbidden, notFound } from './errors.js';

/** Прерывает действие, если у текущего пользователя нет полномочия. */
export function ensure(ctx, permission) {
  if (!can(ctx.me, permission)) forbidden();
}

export function find(db, collection, id, label = 'Запись') {
  const item = db[collection].find((x) => x.id === id);
  if (!item) notFound(label);
  return item;
}

export const findUser = (db, id) => find(db, 'users', id, 'Учётная запись');

export const remove = (db, collection, id) => {
  db[collection] = db[collection].filter((x) => x.id !== id);
};

/** Следующий порядковый номер документа своего вида. Номера не переиспользуются. */
export function nextNo(db, key) {
  db.seq[key] = (db.seq[key] || 0) + 1;
  return db.seq[key];
}

/** Завершает все сеансы пользователя (блокировка, смена пароля). */
export function dropSessionsOf(db, uid) {
  for (const [key, s] of Object.entries(db.sessions)) if (s.uid === uid) delete db.sessions[key];
}
