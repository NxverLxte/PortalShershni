/**
 * Ядро портала. Не зависит от Node.js и браузера: всё платформенное
 * (генерация id, хеширование паролей, время) передаётся снаружи.
 *
 *   const core = createCore({ id, hash, verify });
 *   core.act(db, me, { type: 'decree.add', ... });
 *   core.state(db, me);
 */
import decrees from './actions/decrees.js';
import bills from './actions/bills.js';
import amendments from './actions/amendments.js';
import cases from './actions/cases.js';
import elections from './actions/elections.js';
import citizens from './actions/citizens.js';
import users from './actions/users.js';
import spy from './actions/spy.js';
import { register, authenticate } from './accounts.js';
import { buildState } from './views.js';
import { fail } from './errors.js';

export const HANDLERS = Object.freeze({ ...decrees, ...bills, ...amendments, ...cases, ...elections, ...citizens, ...users, ...spy });

export function createCore({ id, hash, verify, now = () => Date.now(), random = Math.random }) {
  const context = (db, me) => ({ db, me, id, hash, verify, random, now: now() });

  return {
    actions: Object.keys(HANDLERS),
    register: (db, input) => register(context(db, null), input || {}),
    authenticate: (db, login, password) => authenticate(context(db, null), login, password),
    state: (db, me) => buildState(db, me),
    act(db, me, action) {
      if (!me) fail('Требуется вход в личный кабинет', 401);
      const handler = HANDLERS[action?.type];
      if (!handler) fail('Неизвестное действие');
      handler(context(db, me), action);
    },
  };
}

export * from './constants.js';
export { DomainError } from './errors.js';
export { can, permissionsOf, PERMISSIONS } from './permissions.js';
export { emptyDb, migrate, SCHEMA_VERSION } from './schema.js';
