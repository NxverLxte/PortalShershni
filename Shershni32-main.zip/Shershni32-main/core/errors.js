/**
 * Ошибка предметной области: её текст безопасно показывать пользователю.
 * status — HTTP-код, который вернёт сервер.
 */
export class DomainError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.name = 'DomainError';
    this.status = status;
  }
}

export function fail(message, status = 400) {
  throw new DomainError(message, status);
}

export const forbidden = () => fail('Недостаточно полномочий', 403);
export const notFound = (what = 'Запись') => fail(`${what} не найдена`, 404);
