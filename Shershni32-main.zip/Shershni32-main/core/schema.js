/**
 * Структура базы данных и миграции между версиями.
 * База — обычный JSON-объект; сервер хранит его в файле, демо — в памяти.
 */
import { defaultWordlists } from './games/wordlists.js';

export const SCHEMA_VERSION = 3;

export function emptyDb() {
  return {
    version: SCHEMA_VERSION,
    users: [],
    sessions: {},
    decrees: [],
    bills: [],
    amendments: [],
    cases: [],
    candidates: [],
    elections: [],
    replog: [],
    wordlists: defaultWordlists(),
    spyRooms: [],
    seq: {},
  };
}

/** Приводит базу любой прежней версии к текущей. Исходный объект не меняет. */
export function migrate(input) {
  const db = { ...emptyDb(), ...structuredClone(input || {}) };

  // v1 → v2: заявления кандидатов хранились в "congress" и не имели поля post
  if (Array.isArray(db.congress)) {
    if (!db.candidates.length) db.candidates = db.congress;
    delete db.congress;
  }
  for (const c of db.candidates) c.post ||= 'congress';
  for (const e of db.elections) {
    e.votes ||= {};
    e.winners ||= [];
  }
  for (const u of db.users) u.score ??= 0;
  // v2 → v3: игра «Шпион» — темы со словами и комнаты (добавляются из emptyDb())

  db.version = SCHEMA_VERSION;
  return db;
}
