/**
 * Демонстрационные данные. Используются в `npm run demo` и в браузерном демо.
 * Пароль всех демонстрационных учётных записей: demo
 */
import { emptyDb } from './schema.js';

export const DEMO_PASSWORD = 'demo';

export function seedDemo({ id, hash, now = Date.now() }) {
  const db = emptyDb();
  const day = 864e5;
  const pw = hash(DEMO_PASSWORD);
  const user = (login, nick, gender, role, score, extra = {}) => {
    const u = { id: id(), login, pw, nick, gender, role, status: 'approved', score, agent: null, created: now - 400 * day, ...extra };
    db.users.push(u);
    return u;
  };

  const pres = user('prez', 'Максим', 'Шершень', 'president', 1500);
  const vasya = user('vasya', 'Вася', 'Шершень', 'minjust', 1050);
  const anya = user('anya', 'Аня', 'Шершиня', 'citizen', 640);
  const dima = user('dima', 'Дима', 'Шершень', 'citizen', 240);
  const kolyan = user('kolyan', 'Колян', 'Шершень', 'citizen', 0, {
    agent: { reason: 'Систематическое распространение сведений, подрывающих доверие к органам управления сообщества, в интересах иного сообщества.', t: now - 2 * day, by: 'Максим' },
  });
  user('petya', 'Петя', 'Шершень', 'citizen', 500, { status: 'pending', created: now - 3600e3 });

  db.decrees.push(
    { id: id(), no: 2, kind: 'Распоряжение', title: 'О проведении соревнований по дисциплине CS2', text: 'Министерству обороны организовать проведение соревнований по дисциплине CS2 в ближайшую субботу.\n\nПрезидент ШЕРШНЕЙ', t: now - day },
    { id: id(), no: 1, kind: 'Указ', title: 'Об учреждении официального портала ШЕРШНЕЙ', text: 'Руководствуясь статьёй 40 Конституции, постановляю:\n1. Учредить официальный портал сообщества ШЕРШНИ.\n2. Вести на портале реестры актов, законопроектов, предложений поправок, судебных дел, репутации граждан и агентов дестабилизации сообщества.\n3. Настоящий указ вступает в силу с момента опубликования.\n\nПрезидент ШЕРШНЕЙ', t: now - 6 * day },
  );

  db.bills.push(
    { id: id(), no: 2, uid: anya.id, who: anya.nick, title: 'О кворуме Конгресса', note: 'Конституция не определяет кворум Конгресса (ст. 21.2). Законопроект устраняет пробел.', text: 'Статья 1. Кворум Конгресса составляет более половины от установленного числа его членов.\nСтатья 2. Настоящий закон вступает в силу с момента подписания.', status: 'review', t: now - day },
    { id: id(), no: 1, uid: vasya.id, who: vasya.nick, title: 'О порядке проведения собраний граждан', note: 'Закон устанавливает единый порядок созыва и проведения собраний граждан в голосовых каналах.', text: 'Статья 1. Собрание граждан созывается Президентом либо по его поручению Министром юстиции.\nСтатья 2. Объявление о собрании публикуется не позднее чем за сутки до его проведения.\nСтатья 3. Настоящий закон вступает в силу с момента подписания.', status: 'signed', signedAt: now - 3 * day, t: now - 5 * day },
  );

  db.amendments.push({ id: id(), no: 1, uid: anya.id, who: anya.nick, art: 'ст. 21.2', text: 'Определить кворум Конгресса как более половины от установленного числа его членов.', why: 'Отсутствие кворума препятствует принятию законов.', status: 'review', t: now - 2 * day });

  db.cases.push({ id: id(), no: 1, uid: anya.id, who: anya.nick, vsId: kolyan.id, vs: kolyan.nick, cat: 'Нарушение Конституции', art: 'ст. 8.3', text: 'Ответчик неоднократно нарушал порядок в голосовом канале во время собрания граждан, чем препятствовал его проведению.', demand: 'Прошу суд признать действия ответчика нарушением ст. 8.3 Конституции.', status: 'hearing', t: now - day });

  db.candidates.push(
    { id: id(), uid: anya.id, who: anya.nick, post: 'congress', months: 19, text: 'Добьюсь принятия закона о кворуме и прозрачности работы Конгресса.', status: 'ok', t: now - 4 * day },
    { id: id(), uid: dima.id, who: dima.nick, post: 'congress', months: 22, text: 'Предлагаю регулярные отчёты министров перед гражданами.', status: 'ok', t: now - 4 * day },
    { id: id(), uid: vasya.id, who: vasya.nick, post: 'minjust', months: 20, text: 'Обеспечу законность и справедливое правосудие.', status: 'ok', t: now - 12 * day },
  );

  db.elections.push(
    { id: id(), post: 'congress', seats: 1, status: 'open', t: now - day, candidates: [{ id: anya.id, nick: anya.nick }, { id: dima.id, nick: dima.nick }], votes: { [vasya.id]: anya.id, [dima.id]: dima.id }, winners: [] },
    { id: id(), post: 'minjust', seats: 1, status: 'closed', applied: true, t: now - 11 * day, closedAt: now - 9 * day, candidates: [{ id: vasya.id, nick: vasya.nick }], votes: { [pres.id]: vasya.id, [anya.id]: vasya.id, [dima.id]: vasya.id }, winners: [vasya.id] },
  );

  db.replog.push(
    { id: id(), uid: kolyan.id, nick: kolyan.nick, delta: -500, reason: 'Нарушение порядка в голосовом канале', by: pres.nick, t: now - 2 * day },
    { id: id(), uid: vasya.id, nick: vasya.nick, delta: 550, reason: 'За организацию соревнований по дисциплине Dota 2', by: pres.nick, t: now - 4 * day },
  );

  db.spyRooms.push({ id: id(), no: 1, hostId: anya.id, listId: 'dota-heroes', spies: 1, status: 'lobby', players: [anya.id, dima.id, vasya.id], round: null, rounds: 0, t: now - 600e3 });

  db.seq = { decrees: 2, bills: 2, amendments: 1, cases: 1, spyRooms: 1 };
  return db;
}
