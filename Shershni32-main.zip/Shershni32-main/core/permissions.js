/**
 * Полномочия должностей. Единый источник правды: сервер проверяет их
 * при каждом действии, а интерфейс получает список в state.me.perms,
 * чтобы показывать только доступные элементы управления.
 */
export const PERMISSIONS = Object.freeze({
  'decree.manage': ['president'],
  'amendment.review': ['president'],
  'case.judge': ['president', 'minjust'],
  'case.delete': ['president'],
  'candidate.check': ['president', 'minjust'],
  'candidate.approve': ['president'],
  'candidate.delete': ['president'],
  'bill.stage': ['president', 'congress'],
  'bill.sign': ['president'],
  'bill.manage': ['president'],
  'reputation.manage': ['president'],
  'agent.assign': ['president', 'minjust'],
  'agent.remove': ['president'],
  'users.manage': ['president'],
  'elections.manage': ['president'],
  'games.words': ['president'],
  'games.moderate': ['president'],
});

export function can(user, permission) {
  if (!user || user.status !== 'approved') return false;
  return (PERMISSIONS[permission] || []).includes(user.role);
}

export const permissionsOf = (user) => Object.keys(PERMISSIONS).filter((p) => can(user, p));
