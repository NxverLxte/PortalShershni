/** Тесты игры «Шпион»: тайна ролей, ограничения, темы. */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createCore, emptyDb } from '../core/index.js';
import { parseWords } from '../core/actions/spy.js';

let n = 0;
const core = createCore({ id: () => `id${++n}`, hash: (p) => `h:${p}`, verify: (p, h) => h === `h:${p}` });

function world(count = 5) {
  const db = emptyDb();
  const users = [];
  for (let i = 0; i < count; i++) {
    users.push(core.register(db, { login: `user${i}`, password: 'secret1', nick: `Игрок${i}`, gender: 'Шершень' }).user);
  }
  for (const u of users.slice(1)) core.act(db, users[0], { type: 'user.status', uid: u.id, status: 'approved' });
  return { db, users, pres: users[0] };
}

const rejects = (fn, re) => assert.throws(fn, (e) => e.name === 'DomainError' && (!re || re.test(e.message)));
const room = (db) => db.spyRooms[0];

test('новая база содержит четыре темы со словами', () => {
  const db = emptyDb();
  assert.deepEqual(db.wordlists.map((l) => l.id), ['places', 'objects', 'dota-heroes', 'dota-items']);
  for (const l of db.wordlists) assert.ok(l.words.length >= 40, l.title);
});

test('раунд: шпион не видит слово, остальные видят одно и то же слово', () => {
  const { db, users } = world(5);
  const [host, ...rest] = users;
  core.act(db, host, { type: 'spy.create', listId: 'places', spies: 2 });
  const rid = room(db).id;
  for (const u of rest) core.act(db, u, { type: 'spy.join', rid });
  core.act(db, host, { type: 'spy.start', rid });

  const cards = users.map((u) => core.state(db, u).spy.rooms[0].round.card);
  const spies = cards.filter((c) => c.spy);
  const words = new Set(cards.filter((c) => c.word).map((c) => c.word));
  assert.equal(spies.length, 2);
  assert.equal(words.size, 1, 'у всех мирных одно слово');

  // Никто не получает чужие карточки или список шпионов до раскрытия
  const json = JSON.stringify(core.state(db, users[1]).spy);
  assert.equal(json.includes('"spies":['), false);
  assert.equal(core.state(db, users[1]).spy.rooms[0].round.reveal, null);

  core.act(db, host, { type: 'spy.reveal', rid });
  const reveal = core.state(db, users[2]).spy.rooms[0].round.reveal;
  assert.equal(reveal.spies.length, 2);
  assert.ok(words.has(reveal.word));
});

test('ограничения: минимум 3 игрока, мирных не меньше двух, только ведущий управляет', () => {
  const { db, users } = world(4);
  const [host, a, b, c] = users;
  core.act(db, host, { type: 'spy.create', listId: 'objects', spies: 2 });
  const rid = room(db).id;
  core.act(db, a, { type: 'spy.join', rid });
  rejects(() => core.act(db, host, { type: 'spy.start', rid }), /не менее 3/);
  core.act(db, b, { type: 'spy.join', rid });
  rejects(() => core.act(db, host, { type: 'spy.start', rid }), /не более 1/);
  rejects(() => core.act(db, a, { type: 'spy.settings', rid, spies: 1 }), /полномочий/);
  core.act(db, host, { type: 'spy.settings', rid, spies: 1 });
  core.act(db, host, { type: 'spy.start', rid });
  rejects(() => core.act(db, c, { type: 'spy.join', rid }), /Идёт раунд/);
  rejects(() => core.act(db, a, { type: 'spy.create', listId: 'objects', spies: 1 }), /уже находитесь/);
});

test('если ведущий покидает комнату, ведущим становится следующий игрок', () => {
  const { db, users } = world(3);
  core.act(db, users[0], { type: 'spy.create', listId: 'objects', spies: 1 });
  const rid = room(db).id;
  core.act(db, users[1], { type: 'spy.join', rid });
  core.act(db, users[0], { type: 'spy.leave', rid });
  assert.equal(room(db).hostId, users[1].id);
  core.act(db, users[1], { type: 'spy.leave', rid });
  assert.equal(db.spyRooms.length, 0, 'пустая комната удаляется');
});

test('темы: Президент добавляет слова списком, повторы отбрасываются, гражданин не может', () => {
  const { db, pres, users } = world(2);
  core.act(db, pres, { type: 'wordlist.create', title: 'Мемы', words: 'Кот\nПёс, кот;  Хомяк  ' });
  const memes = db.wordlists.find((l) => l.title === 'Мемы');
  assert.deepEqual(memes.words, ['Кот', 'Пёс', 'Хомяк']);
  core.act(db, pres, { type: 'wordlist.add', id: memes.id, words: 'хомяк\nПопугай' });
  assert.deepEqual(memes.words, ['Кот', 'Пёс', 'Хомяк', 'Попугай']);
  rejects(() => core.act(db, pres, { type: 'wordlist.add', id: memes.id, words: 'Кот' }), /Новых слов не найдено/);
  rejects(() => core.act(db, users[1], { type: 'wordlist.add', id: memes.id, words: 'Х' }), /полномочий/);
  assert.equal(core.state(db, users[1]).spy.lists[0].words, undefined, 'слова тем видит только редактор');
  assert.ok(core.state(db, pres).spy.lists[0].words.length > 0);
});

test('разбор слов списком', () => {
  assert.deepEqual(parseWords(' A ;b\n\n c , a '), ['A', 'b', 'c']);
});
