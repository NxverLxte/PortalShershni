/** Модульные тесты ядра: права, процедуры, выборы. Запуск: npm test */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createCore, emptyDb, migrate } from '../core/index.js';

let n = 0;
const core = createCore({ id: () => `id${++n}`, hash: (p) => `h:${p}`, verify: (p, h) => h === `h:${p}` });

/** База с Президентом, министром юстиции, членом Конгресса и двумя гражданами. */
function world() {
  const db = emptyDb();
  const reg = (login, nick) => core.register(db, { login, password: 'secret1', nick, gender: 'Шершень' }).user;
  const pres = reg('prez', 'Президент');
  const others = [reg('just', 'Юстиция'), reg('cong', 'Конгрессмен'), reg('anya', 'Аня'), reg('dima', 'Дима')];
  for (const u of others) core.act(db, pres, { type: 'user.status', uid: u.id, status: 'approved' });
  const [just, cong, anya, dima] = others;
  core.act(db, pres, { type: 'user.role', uid: just.id, role: 'minjust' });
  core.act(db, pres, { type: 'user.role', uid: cong.id, role: 'congress' });
  return { db, pres, just, cong, anya, dima };
}

const rejects = (fn, re) => assert.throws(fn, (e) => e.name === 'DomainError' && (!re || re.test(e.message)));

test('первый зарегистрированный — Президент, остальные ждут одобрения', () => {
  const db = emptyDb();
  const a = core.register(db, { login: 'Alpha', password: 'secret1', nick: 'A', gender: 'Шершень' });
  const b = core.register(db, { login: 'beta', password: 'secret1', nick: 'B', gender: 'Шершиня' });
  assert.equal(a.first, true);
  assert.equal(a.user.role, 'president');
  assert.equal(a.user.login, 'alpha');
  assert.equal(b.user.status, 'pending');
  rejects(() => core.authenticate(db, 'beta', 'secret1'), /рассмотрении/);
  rejects(() => core.authenticate(db, 'alpha', 'wrong'), /Неверный/);
  rejects(() => core.register(db, { login: 'ALPHA', password: 'secret1', nick: 'C', gender: 'Шершень' }), /занят/);
});

test('гражданин не может издавать указы и назначать себя на должности', () => {
  const { db, anya } = world();
  rejects(() => core.act(db, anya, { type: 'decree.add', kind: 'Указ', title: 'x', text: 'y' }), /полномочий/);
  rejects(() => core.act(db, anya, { type: 'user.role', uid: anya.id, role: 'minjust' }), /полномочий/);
});

test('Президента нельзя понизить или заблокировать, должность Президента не передаётся', () => {
  const { db, pres, anya } = world();
  rejects(() => core.act(db, pres, { type: 'user.status', uid: pres.id, status: 'blocked' }));
  rejects(() => core.act(db, pres, { type: 'user.role', uid: anya.id, role: 'president' }));
});

test('законопроект: Конгресс принимает, подписывает только Президент', () => {
  const { db, pres, cong, anya } = world();
  core.act(db, anya, { type: 'bill.add', title: 'О кворуме', note: 'n', text: 't' });
  const id = db.bills[0].id;
  rejects(() => core.act(db, anya, { type: 'bill.stage', id, status: 'review' }), /полномочий/);
  core.act(db, cong, { type: 'bill.stage', id, status: 'passed' });
  rejects(() => core.act(db, cong, { type: 'bill.stage', id, status: 'signed' }), /полномочий/);
  core.act(db, pres, { type: 'bill.stage', id, status: 'signed' });
  assert.equal(core.state(db, null).laws.length, 1, 'подписанный закон виден гостям');
});

test('иск: нельзя к себе; решение выносит Министр юстиции', () => {
  const { db, just, anya, dima } = world();
  rejects(() => core.act(db, anya, { type: 'case.add', defendant: anya.id, cat: 'Иное', text: 't', demand: 'd' }), /самому себе/);
  core.act(db, anya, { type: 'case.add', defendant: dima.id, cat: 'Иное', text: 't', demand: 'd' });
  const id = db.cases[0].id;
  rejects(() => core.act(db, dima, { type: 'case.decision', id, text: 'x' }), /полномочий/);
  core.act(db, just, { type: 'case.decision', id, text: 'Иск удовлетворить' });
  assert.equal(db.cases[0].status, 'decided');
});

test('выборы: тайное голосование, один голос, агенты не голосуют, итоги назначают избранных', () => {
  const { db, pres, just, anya, dima, cong } = world();
  core.act(db, anya, { type: 'candidate.apply', post: 'congress', months: 20, text: 'p' });
  const cand = db.candidates[0].id;
  rejects(() => core.act(db, just, { type: 'candidate.review', id: cand, status: 'ok' }), /полномочий/);
  core.act(db, pres, { type: 'candidate.review', id: cand, status: 'ok' });
  core.act(db, pres, { type: 'election.open', post: 'congress', seats: 1 });
  const eid = db.elections[0].id;

  core.act(db, pres, { type: 'agent.assign', uid: cong.id, reason: 'основание' });
  assert.equal(db.users.find((u) => u.id === cong.id).role, 'citizen', 'агент освобождается от должности');
  rejects(() => core.act(db, cong, { type: 'election.vote', eid, cid: anya.id }), /8\.1/);

  core.act(db, dima, { type: 'election.vote', eid, cid: anya.id });
  rejects(() => core.act(db, dima, { type: 'election.vote', eid, cid: anya.id }), /уже/);

  const open = core.state(db, dima).elections[0];
  assert.equal(open.results, null, 'итоги скрыты до завершения');
  assert.equal(open.turnout, 1);
  assert.equal(JSON.stringify(core.state(db, dima)).includes('"votes"'), false, 'голоса не раскрываются');

  core.act(db, pres, { type: 'election.close', eid });
  core.act(db, pres, { type: 'election.apply', eid });
  assert.equal(db.users.find((u) => u.id === anya.id).role, 'congress');
});

test('пароли и сеансы не попадают в состояние', () => {
  const { db, pres } = world();
  db.sessions.x = { uid: pres.id, exp: Date.now() + 1e6 };
  const json = JSON.stringify(core.state(db, pres));
  assert.equal(json.includes('h:secret1'), false);
  assert.equal(json.includes('sessions'), false);
});

test('миграция базы первой версии', () => {
  const old = { users: [], congress: [{ id: 'c1', uid: 'u', status: 'ok' }], elections: [{ id: 'e', candidates: [] }] };
  const db = migrate(old);
  assert.equal(db.version, 3);
  assert.ok(db.wordlists.length >= 4, 'темы «Шпиона» добавлены');
  assert.equal(db.candidates[0].post, 'congress');
  assert.equal('congress' in db, false);
  assert.deepEqual(db.elections[0].votes, {});
});

test('репутация: новичок начинает с 500, звания по порогам, при 0 — автоматически в реестр агентов', async () => {
  const { rankOf, START_SCORE } = await import('../core/constants.js');
  assert.equal(START_SCORE, 500);
  assert.equal(rankOf(1000), 'Почётный шершень');
  assert.equal(rankOf(999), 'Шершень');
  assert.equal(rankOf(300), 'Шершень');
  assert.equal(rankOf(299), 'Ненадёжный шершень');
  assert.equal(rankOf(1), 'Ненадёжный шершень');
  assert.equal(rankOf(0), 'Агент');
  assert.equal(rankOf(-50), 'Агент');

  const { db, pres, just, anya } = world();
  assert.equal(anya.score, 500);
  core.act(db, pres, { type: 'reputation.change', uid: just.id, delta: -500, reason: 'Нарушение' });
  const j = db.users.find((u) => u.id === just.id);
  assert.ok(j.agent, 'внесён в реестр автоматически');
  assert.equal(j.role, 'citizen', 'освобождён от должности');
  // Президент в реестр не вносится, даже при нулевой репутации
  core.act(db, pres, { type: 'reputation.change', uid: pres.id, delta: -600, reason: 'Проверка' });
  assert.equal(db.users.find((u) => u.id === pres.id).agent, null);
});
