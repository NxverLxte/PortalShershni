/** Интеграционные тесты HTTP API: сервер поднимается на свободном порту с базой в памяти. */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server/app.js';
import { loadConfig } from '../server/config.js';
import { MemoryStore } from '../server/storage.js';

let app;
let base;

before(async () => {
  const config = { ...loadConfig({}, []), port: 0 };
  app = createApp(config, { store: new MemoryStore(), log: () => {} });
  await new Promise((resolve) => app.server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${app.server.address().port}`;
});

after(() => new Promise((resolve) => app.server.close(resolve)));

/** Клиент с собственной cookie, как отдельный браузер. */
function client() {
  let cookie = '';
  return async (path, body) => {
    const res = await fetch(base + path, {
      method: body ? 'POST' : 'GET',
      headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), cookie },
      body: body ? JSON.stringify(body) : undefined,
    });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    return { status: res.status, body: await res.json() };
  };
}

test('полный сценарий: регистрация, одобрение, вход, действие', async () => {
  const prez = client();
  const anya = client();

  assert.equal((await prez('/api/register', { login: 'prez', password: 'secret1', nick: 'П', gender: 'Шершень' })).body.first, true);
  await anya('/api/register', { login: 'anya', password: 'secret1', nick: 'Аня', gender: 'Шершиня' });

  assert.equal((await anya('/api/login', { login: 'anya', password: 'secret1' })).status, 403);
  assert.equal((await prez('/api/login', { login: 'prez', password: 'secret1' })).status, 200);

  const state = (await prez('/api/state')).body;
  assert.ok(state.me.perms.includes('users.manage'));
  const anyaId = state.accounts.find((u) => u.login === 'anya').id;
  await prez('/api/act', { type: 'user.status', uid: anyaId, status: 'approved' });

  assert.equal((await anya('/api/login', { login: 'anya', password: 'secret1' })).status, 200);
  const res = await anya('/api/act', { type: 'decree.add', kind: 'Указ', title: 'x', text: 'y' });
  assert.equal(res.status, 403);
});

test('гость не может выполнять действия и не видит реестры', async () => {
  const guest = client();
  assert.equal((await guest('/api/act', { type: 'bill.add' })).status, 401);
  const s = (await guest('/api/state')).body;
  assert.equal(s.me, null);
  assert.equal(s.cases, undefined);
});

test('ошибочное действие не меняет базу (транзакция откатывается)', async () => {
  const before = JSON.stringify(app.db);
  const prez = client();
  await prez('/api/login', { login: 'prez', password: 'secret1' });
  const snapshot = JSON.stringify({ ...app.db, sessions: {} });
  const r = await prez('/api/act', { type: 'case.add', defendant: 'нет-такого', cat: 'Иное', text: 't', demand: 'd' });
  assert.equal(r.status, 404);
  assert.equal(JSON.stringify({ ...app.db, sessions: {} }), snapshot);
  assert.ok(before);
});

test('запросы не в JSON отклоняются (защита от CSRF через формы)', async () => {
  const res = await fetch(`${base}/api/login`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'login=a' });
  assert.equal(res.status, 415);
});

test('статические файлы: ядро доступно браузеру, выход за пределы папки запрещён', async () => {
  assert.equal((await fetch(`${base}/core/constants.js`)).status, 200);
  assert.equal((await fetch(`${base}/js/main.js`)).headers.get('content-type'), 'text/javascript; charset=utf-8');
  assert.equal((await fetch(`${base}/core/%2e%2e/server/crypto.js`)).status, 404);
});
