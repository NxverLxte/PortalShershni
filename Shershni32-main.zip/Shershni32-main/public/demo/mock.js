/**
 * Демонстрационная версия без сервера: подменяет fetch для /api/* и выполняет
 * действия тем же ядром (core/), что и настоящий сервер. Данные живут в памяти вкладки.
 * Подключается только сборкой `npm run build:demo` — на рабочем сайте не используется.
 */
import { createCore, DomainError, ROLES } from '../core/index.js';
import { seedDemo, DEMO_PASSWORD } from '../core/demo.js';
import { refresh, onChange } from '../js/store.js';

let counter = 0;
const id = () => `d${Date.now().toString(36)}${(counter++).toString(36)}`;
const hash = (p) => `demo:${p}`;
const verify = (p, h) => h === `demo:${p}`;

const core = createCore({ id, hash, verify });
let db = seedDemo({ id, hash });
let currentId = db.users.find((u) => u.role === 'president').id;

const currentUser = () => {
  const u = db.users.find((x) => x.id === currentId);
  return u && u.status === 'approved' ? u : null;
};

const reply = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

function handle(path, body) {
  switch (path) {
    case '/api/state':
      return reply(200, core.state(db, currentUser()));
    case '/api/login':
      currentId = core.authenticate(db, body.login, body.password).id;
      return reply(200, { ok: true });
    case '/api/logout':
      currentId = null;
      return reply(200, { ok: true });
    case '/api/register': {
      const { first } = core.register(db, body);
      return reply(200, { ok: true, first });
    }
    case '/api/act': {
      const me = currentUser();
      if (!me) return reply(401, { error: 'Требуется вход в личный кабинет' });
      const snapshot = structuredClone(db);
      try {
        core.act(db, me, body);
      } catch (err) {
        db = snapshot;
        throw err;
      }
      return reply(200, core.state(db, currentUser()));
    }
    default:
      return reply(404, { error: 'Не найдено' });
  }
}

const realFetch = window.fetch.bind(window);
window.fetch = async (input, init = {}) => {
  const url = new URL(typeof input === 'string' ? input : input.url, location.href);
  if (!url.pathname.startsWith('/api/')) return realFetch(input, init);
  await new Promise((r) => setTimeout(r, 60)); // имитация сети
  try {
    return handle(url.pathname, init.body ? JSON.parse(init.body) : {});
  } catch (err) {
    if (err instanceof DomainError) return reply(err.status, { error: err.message });
    console.error(err);
    return reply(500, { error: 'Внутренняя ошибка' });
  }
};

/* --- Панель «просмотр от имени» --- */
const bar = document.createElement('div');
bar.className = 'demo-bar';
bar.innerHTML = `
  <b>Демо</b>
  <label><span class="demo-bar__label">Просмотр от имени</span>
    <select aria-label="Просмотр от имени"></select>
  </label>
  <span class="demo-bar__hint" title="Пароль всех демонстрационных учётных записей: ${DEMO_PASSWORD}">?</span>`;
const select = bar.querySelector('select');

function syncSelect() {
  const people = db.users.filter((u) => u.status === 'approved');
  select.innerHTML = `<option value="">Гость</option>${people
    .map((u) => `<option value="${u.id}">${u.nick} — ${ROLES[u.role]}</option>`)
    .join('')}`;
  select.value = currentUser() ? currentId : '';
}

select.addEventListener('change', () => {
  currentId = select.value || null;
  refresh();
});
onChange(syncSelect);

document.addEventListener('DOMContentLoaded', () => {
  document.body.append(bar);
  syncSelect();
});
