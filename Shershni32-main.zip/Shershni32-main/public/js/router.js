/**
 * Маршрутизатор по #хешу. Раздел монтируется один раз при переходе
 * (формы сохраняют введённый текст), а при изменении данных вызывается update().
 */
import { ROUTES, GATE, NOT_FOUND, DEFAULT_ROUTE, findRoute } from './routes.js';
import { getState, can } from './store.js';
import { applyAccess } from './ui/dom.js';
import { markActive } from './ui/header.js';
import { animateEnter } from './ui/motion.js';

const SITE = 'Портал ШЕРШНЕЙ';
let current = null; // { route, root }

function resolve(id, state) {
  const route = findRoute(id);
  if (!route) return { route: NOT_FOUND };
  const me = state?.me;
  if (route.access === 'citizen' && !me) return { route: GATE };
  if (route.access === 'guest' && me) return { redirect: 'kabinet' };
  if (route.access.startsWith('perm:') && !can(route.access.slice(5))) return { redirect: DEFAULT_ROUTE };
  return { route };
}

function mount(route, app) {
  const root = document.createElement('div');
  root.dataset.view = route.id;
  root.className = 'view-enter';
  route.view.mount(root, getState());
  app.replaceChildren(root);
  current = { route, root };
}

function update() {
  if (!current) return;
  const state = getState();
  if (state && current.route.view.update) current.route.view.update(current.root, state);
  applyAccess(current.root);
}

/** Показывает раздел из адресной строки. force — перемонтировать, даже если раздел тот же. */
export function render({ scroll = false, force = false } = {}) {
  const app = document.getElementById('app');
  const id = location.hash.slice(1) || DEFAULT_ROUTE;
  const { route, redirect } = resolve(id, getState());
  if (redirect) {
    location.replace(`#${redirect}`);
    return;
  }
  const fresh = force || current?.route !== route;
  if (fresh) {
    mount(route, app);
    if (scroll) {
      window.scrollTo({ top: 0, behavior: 'instant' });
      app.focus({ preventScroll: true });
    }
  }
  update();
  // Анимации появления — только при первом открытии раздела и когда данные уже есть
  if (fresh && getState()) animateEnter(current.root);
  markActive(route === GATE ? id : route.id);
  document.title = route.id === DEFAULT_ROUTE ? SITE : `${route.title} — ${SITE}`;
}

/** Как часто обновлять данные в текущем разделе (мс); у игр — чаще. */
export const currentPoll = () => current?.route.view.poll || null;

export function startRouter() {
  window.addEventListener('hashchange', () => render({ scroll: true }));
}

export { ROUTES };
