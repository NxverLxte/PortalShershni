/** Мелкие общие функции интерфейса. */

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/** Экранирование для вставки в HTML. Применяется ко всем данным пользователей. */
export const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ESC[c]);

export const formatDate = (t) =>
  t ? new Date(t).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }) : '';

export const formatToday = () => {
  const s = new Date().toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  return s.charAt(0).toUpperCase() + s.slice(1);
};

export const pad = (n, width = 3) => String(n).padStart(width, '0');

export const initial = (name) => ([...String(name || '?')][0] || '?').toUpperCase();

export const signed = (n) => (n > 0 ? `+${n}` : String(n));

export const percent = (part, total) => (total ? Math.round((part / total) * 100) : 0);

/** Склонение: plural(5, ['голос', 'голоса', 'голосов']) → «голосов». */
export function plural(n, [one, few, many]) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
  return many;
}

/** Объект из полей формы. Флажки без name не попадают. */
export const formData = (form) => Object.fromEntries(new FormData(form));
