/**
 * Состояние портала на клиенте. Сервер на каждый запрос возвращает полное
 * состояние, поэтому клиент не ведёт собственную копию логики — только показывает.
 */
import { api } from './api.js';

let state = null;
const listeners = new Set();

export const getState = () => state;

export function onChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function set(next) {
  state = next;
  for (const fn of listeners) fn(state);
  return state;
}

export const refresh = async () => set(await api.get('/api/state'));
export const act = async (action) => set(await api.post('/api/act', action));
export const register = (data) => api.post('/api/register', data);

export async function login(data) {
  await api.post('/api/login', data);
  return refresh();
}

export async function logout() {
  await api.post('/api/logout');
  return refresh();
}

/** Есть ли у текущего пользователя полномочие (список приходит с сервера). */
export const can = (perm) => Boolean(state?.me?.perms?.includes(perm));
export const me = () => state?.me || null;
