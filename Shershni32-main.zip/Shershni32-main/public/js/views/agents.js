/** Реестр агентов дестабилизации сообщества (ст. 8.1). */
import { actionButton, controls, docRow, field, list, options, pageHead, sectionTitle, headStats } from '../ui/components.js';
import { fill, fillSelect } from '../ui/dom.js';
import { can } from '../store.js';
import { esc } from '../utils.js';

export default {
  mount(root) {
    root.innerHTML = `
      ${pageHead({
        crumb: 'Реестр агентов',
        title: 'Реестр агентов дестабилизации сообщества',
        lead: 'Ведётся Министерством юстиции в соответствии со ст. 8.1 Конституции. Статус является мерой защиты государственного устройства и не является мерой ответственности. Лицо, внесённое в реестр, не вправе замещать государственные должности и участвовать в народных голосованиях. Статус снимается решением Президента.',
      })}
      <section class="band"><div class="in split">
        <div>${sectionTitle('Реестр')}<div data-region="list"></div></div>
        <div class="sticky" data-perm="agent.assign">
          <form class="form" data-action="agent.assign" data-success="Запись внесена в реестр">
            <h2>Внесение в реестр</h2>
            <label>Гражданин<select name="uid" required data-options="candidates"></select></label>
            <label>Основание<textarea name="reason" required></textarea></label>
            <p class="note">При внесении в реестр гражданин освобождается от замещаемой государственной должности.</p>
            <button type="submit">Внести в реестр</button>
          </form>
        </div>
      </div></section>`;
  },

  update(root, S) {
    fill(root, 'head', headStats([[S.citizens.filter((c) => c.agent).length, 'записей в реестре', S.citizens.some((c) => c.agent) ? 'red' : '']]));
    const agents = S.citizens.filter((c) => c.agent).sort((a, b) => a.agent.t - b.agent.t);
    fill(root, 'list', list(agents, (c, i) => docRow({
      no: `Запись № ${i + 1}`,
      date: c.agent.t,
      body: `
        <h3>${esc(c.nick)}</h3>
        ${field('Основание', c.agent.reason)}
        ${can('agent.remove') ? controls(actionButton('Снять статус', 'agent.remove', { uid: c.id }, { confirm: 'Подтвердить снятие статуса' })) : ''}`,
    }), 'Записи в реестре отсутствуют.'));
    fillSelect(root, 'candidates', options(S.citizens.filter((c) => !c.agent && c.role !== 'president').map((c) => [c.id, c.nick])));
  },
};
