/** Выборы: голосование, кандидаты, итоги (ст. 7.2, 8.1, 19–20.2). */
import { CANDIDATE_STATUS, CONGRESS_MIN_MONTHS, POSTS } from '../../core/constants.js';
import { actionButton, controls, deleteButton, docRow, empty, field, list, meta, metaItem, options, pageHead, sectionTitle, statusSelect, statusTag, tag, headStats } from '../ui/components.js';
import { fill } from '../ui/dom.js';
import { can } from '../store.js';
import { esc, formatDate, percent, plural } from '../utils.js';
import { avatar, person } from '../ui/people.js';

const POST_OPTIONS = options(Object.entries(POSTS));

const title = (e) => `Выборы: ${POSTS[e.post]}${e.post === 'congress' ? ` (${e.seats} ${plural(e.seats, ['мандат', 'мандата', 'мандатов'])})` : ''}`;

function ballot(e, S) {
  const voters = S.citizens.filter((c) => !c.agent).length;
  let body;
  if (e.myVote) {
    const chosen = e.candidates.find((c) => c.id === e.myVote);
    body = `<p class="text">Ваш голос учтён: <b>${esc(chosen?.nick || '')}</b>. Голос не может быть изменён.</p>`;
  } else if (S.me.agent) {
    body = '<p class="text red">Лица, внесённые в реестр агентов дестабилизации, не участвуют в голосовании (ст. 8.1).</p>';
  } else {
    body = `
      <form data-action="election.vote" data-eid="${esc(e.id)}" data-success="Ваш голос учтён">
        ${e.candidates.map((c) => `<label class="candidate"><input type="radio" name="cid" value="${esc(c.id)}" required>${avatar(c.nick, { size: 'sm' })}${esc(c.nick)}</label>`).join('')}
        <div class="btn-row mt-s"><button type="submit">Проголосовать</button><span class="note">Голосование тайное. Голос подаётся один раз.</span></div>
      </form>`;
  }
  return `
    <div class="ballot">
      ${meta(tag('Голосование открыто', 'ok'), metaItem(`Назначены ${formatDate(e.t)}`), metaItem(`Проголосовало: ${e.turnout} из ${voters}`))}
      <h3>${esc(title(e))}</h3>
      ${body}
      ${can('elections.manage') ? controls(actionButton('Завершить голосование', 'election.close', { eid: e.id }, { confirm: 'Подтвердить завершение' })) : ''}
    </div>`;
}

function results(e) {
  const total = Object.values(e.results).reduce((a, b) => a + b, 0);
  return [...e.candidates]
    .sort((a, b) => e.results[b.id] - e.results[a.id])
    .map((c) => {
      const n = e.results[c.id];
      const won = e.winners.includes(c.id);
      return `
        <div class="result${won ? ' result--won' : ''}">
          <b>${esc(c.nick)}${won ? ' — избран' : ''}</b>
          <div class="result__bar"><i style="width:${percent(n, total)}%"></i></div>
          <span class="num">${n} ${plural(n, ['голос', 'голоса', 'голосов'])} · ${percent(n, total)}%</span>
        </div>`;
    })
    .join('');
}

const pastRow = (e) => docRow({
  no: 'Завершены',
  date: e.closedAt,
  body: `
    <h3>${esc(title(e))}</h3>
    ${meta(metaItem(`Явка: ${e.turnout}`), e.applied ? tag('Итоги утверждены', 'ok') : tag('Итоги не утверждены'))}
    ${results(e)}
    ${can('elections.manage') ? controls(
      !e.applied && actionButton('Утвердить итоги и назначить избранных', 'election.apply', { eid: e.id }, { primary: true, confirm: 'Подтвердить утверждение итогов' }),
      deleteButton('election.delete', { eid: e.id }),
    ) : ''}`,
});

function candidateRow(x) {
  const approve = can('candidate.approve');
  return docRow({
    no: esc(POSTS[x.post]),
    date: x.t,
    body: `
      <div class="mb-s">${person(x.who, { sub: `Стаж в сообществе: ${x.months} мес.` })}</div>
      ${meta(statusTag(CANDIDATE_STATUS, x.status))}
      ${field('Предвыборная программа', x.text)}
      ${can('candidate.check') ? controls(
        statusSelect('candidate.review', { id: x.id }, CANDIDATE_STATUS, x.status, { allowed: approve ? null : ['check', 'no'] }),
        can('candidate.delete') && deleteButton('candidate.delete', { id: x.id }),
      ) : ''}`,
  });
}

export default {
  mount(root) {
    root.innerHTML = `
      ${pageHead({
        crumb: 'Выборы',
        title: 'Выборы',
        lead: 'Граждане избирают членов Конгресса, Министра юстиции и Министра обороны (ст. 7.2). Выборы и число мандатов назначаются Президентом (ст. 20.2). Голосование тайное; каждый гражданин голосует один раз. Лица, внесённые в реестр агентов дестабилизации, в голосовании не участвуют (ст. 8.1).',
      })}
      <section class="band"><div class="in">
        ${sectionTitle('Голосование')}
        <div data-region="ballots"></div>
        <form class="form mt-m" data-perm="elections.manage" data-action="election.open" data-success="Выборы назначены" style="max-width:640px">
          <h2>Назначение выборов</h2>
          <p class="note">В бюллетень включаются кандидаты, регистрация которых утверждена Президентом.</p>
          <div class="field-row">
            <label>Должность<select name="post">${POST_OPTIONS}</select></label>
            <label>Число мандатов<input name="seats" type="number" min="1" max="50" value="3"></label>
          </div>
          <button type="submit">Назначить выборы</button>
        </form>
      </div></section>

      <section class="band band--flush"><div class="in split">
        <div>${sectionTitle('Кандидаты')}<div data-region="candidates"></div></div>
        <div class="sticky">
          <form class="form" data-action="candidate.apply" data-success="Заявление кандидата зарегистрировано">
            <h2>Заявление кандидата</h2>
            <label>Должность<select name="post">${POST_OPTIONS}</select></label>
            <label>Стаж в сообществе, месяцев<input name="months" type="number" min="0" max="600" required></label>
            <label>Предвыборная программа<textarea name="text" required></textarea></label>
            <p class="note">Для кандидатов в Конгресс требуется стаж не менее ${CONGRESS_MIN_MONTHS} месяцев (ст. 19). Заявление проверяет Министерство юстиции, регистрацию утверждает Президент.</p>
            <button type="submit">Подать заявление</button>
          </form>
        </div>
      </div></section>

      <section class="band band--flush"><div class="in">
        ${sectionTitle('Итоги выборов')}
        <div data-region="past"></div>
      </div></section>`;
  },

  update(root, S) {
    fill(root, 'head', headStats([[S.elections.filter((e) => e.status === 'open').length, 'голосований открыто', S.elections.some((e) => e.status === 'open') ? 'gold' : ''], [S.candidates.filter((c) => c.status === 'ok').length, 'зарегистрированных кандидатов']]));
    const open = S.elections.filter((e) => e.status === 'open');
    const closed = S.elections.filter((e) => e.status === 'closed');
    fill(root, 'ballots', open.length ? open.map((e) => ballot(e, S)).join('') : empty('Голосование не проводится. Выборы назначаются Президентом.'));
    fill(root, 'candidates', list(S.candidates, candidateRow, 'Заявления кандидатов не поступали.'));
    fill(root, 'past', list(closed, pastRow, 'Выборы не проводились.'));
  },
};
