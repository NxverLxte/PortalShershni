/** Личный кабинет: карточка гражданина, сводка по документам, смена пароля. */
import { ROLES } from '../../core/constants.js';
import { pageHead, sectionTitle, tag } from '../ui/components.js';
import { fill } from '../ui/dom.js';
import { avatar, rankBadge, rankProgress } from '../ui/people.js';
import { esc, formatDate } from '../utils.js';

function profile(me) {
  const progress = rankProgress(me.score);
  return `
    <div class="profile">
      ${avatar(me.nick, { role: me.role, agent: Boolean(me.agent), size: 'lg' })}
      <div>
        <div class="eyebrow">${esc(me.gender)} · гражданин с ${esc(formatDate(me.since))}</div>
        <h2>${esc(me.nick)}</h2>
        <div class="profile__role">${esc(ROLES[me.role])} · логин ${esc(me.login)}</div>
        <div class="meta">${rankBadge(me.score)}<span>Репутация: <b class="${me.score < 300 ? 'red' : me.score >= 1000 ? 'gold' : ''}">${me.score}</b></span>${me.agent ? tag('Внесён в реестр агентов дестабилизации', 'bad') : ''}</div>
        ${progress ? `
          <div class="profile__next">
            <div class="progress"><i style="width:${progress.percent}%"></i></div>
            <p class="note">До звания «${esc(progress.next)}» — ${progress.need} ед. репутации</p>
          </div>` : '<p class="note mt-s">Достигнуто высшее звание.</p>'}
      </div>
    </div>`;
}

export default {
  mount(root) {
    root.innerHTML = `
      ${pageHead({ crumb: 'Личный кабинет', title: 'Личный кабинет', compact: true })}
      <section class="band"><div class="in">
        <div data-region="profile"></div>
        <div data-region="stats"></div>
      </div></section>
      <section class="band band--flush"><div class="in split">
        <div>
          ${sectionTitle('Мои документы')}
          <div data-region="docs"></div>
        </div>
        <form class="form" data-action="me.password" data-success="Пароль изменён">
          <h2>Смена пароля</h2>
          <label>Действующий пароль<input name="old" type="password" required autocomplete="current-password"></label>
          <label>Новый пароль<input name="password" type="password" required minlength="6" autocomplete="new-password"></label>
          <button type="submit">Сменить пароль</button>
        </form>
      </div></section>`;
  },

  update(root, S) {
    const me = S.me;
    const mine = (items) => items.filter((x) => x.uid === me.id);
    const bills = mine(S.bills);
    const amendments = mine(S.amendments);
    const cases = mine(S.cases);
    fill(root, 'profile', profile(me));
    fill(root, 'stats', `
      <div class="profile-stats">
        <div><b>${bills.length}</b><span>Законопроектов</span></div>
        <div><b>${amendments.length}</b><span>Предложений поправок</span></div>
        <div><b>${cases.length}</b><span>Исков</span></div>
        <div><b>${S.replog.filter((l) => l.uid === me.id).length}</b><span>Решений о репутации</span></div>
      </div>`);
    const rows = [
      ...bills.map((x) => ({ t: x.t, href: '#zakony', kind: 'Законопроект', title: x.title })),
      ...amendments.map((x) => ({ t: x.t, href: '#popravki', kind: 'Поправка', title: `О внесении изменений в ${x.art}` })),
      ...cases.map((x) => ({ t: x.t, href: '#sud', kind: 'Иск', title: `Истец ${x.who}, ответчик ${x.vs}` })),
    ].sort((a, b) => b.t - a.t);
    fill(root, 'docs', rows.length
      ? rows.map((r) => `<article class="doc"><div class="doc__no"><b>${esc(r.kind)}</b>${esc(formatDate(r.t))}</div><div><h3><a href="${r.href}">${esc(r.title)}</a></h3></div></article>`).join('')
      : '<div class="empty">Вы ещё не подавали документов.</div>');
  },
};
