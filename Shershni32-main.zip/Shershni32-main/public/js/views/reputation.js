/** Репутация граждан: рейтинг, журнал изменений, форма изменения (Президент). */
import { ROLES } from '../../core/constants.js';
import { person, rankBadge } from '../ui/people.js';
import { docRow, list, options, pageHead, sectionTitle, table, headStats } from '../ui/components.js';
import { fill, fillSelect } from '../ui/dom.js';
import { esc, signed } from '../utils.js';

const COLUMNS = [{ label: 'Место', num: true }, { label: 'Гражданин' }, { label: 'Должность' }, { label: 'Звание' }, { label: 'Репутация', num: true }];

const deltaClass = (n) => (n < 0 ? 'red' : n > 0 ? 'gold' : '');
/** Цвет значения репутации: ниже 300 — красный, от 1000 — золотой. */
export const scoreClass = (n) => (n < 300 ? 'red' : n >= 1000 ? 'gold' : '');

export default {
  query: '',

  mount(root) {
    this.query = '';
    root.innerHTML = `
      ${pageHead({
        crumb: 'Репутация',
        title: 'Репутация граждан',
        lead: 'Репутация изменяется решением Президента с указанием основания. Звания: от 1000 — почётный шершень; от 300 — шершень; от 1 до 299 — ненадёжный шершень; 0 и ниже — агент. При снижении репутации до 0 гражданин автоматически вносится в реестр агентов дестабилизации (ст. 8.1). Новый гражданин получает 500.',
      })}
      <section class="band"><div class="in">
        <label class="search">Поиск гражданина<input type="search" data-search placeholder="Имя гражданина" autocomplete="off"></label>
        <div data-region="rating"></div>
        <div class="split mt-l">
          <div>${sectionTitle('Журнал изменений')}<div data-region="log"></div></div>
          <div data-perm="reputation.manage">
            <form class="form" data-action="reputation.change" data-success="Изменение репутации утверждено">
              <h2>Изменение репутации</h2>
              <label>Гражданин<select name="uid" required data-options="citizens"></select></label>
              <label>Изменение (+ или −)<input name="delta" type="number" required step="1" value="10"></label>
              <label>Основание<input name="reason" required maxlength="200"></label>
              <button type="submit">Утвердить</button>
            </form>
          </div>
        </div>
      </div></section>`;

    root.querySelector('[data-search]').addEventListener('input', (e) => {
      this.query = e.target.value.trim().toLowerCase();
      this.update(root, this.last);
    });
  },

  update(root, S) {
    fill(root, 'head', headStats([[S.citizens.length, 'граждан'], [S.citizens.filter((c) => c.score >= 1000).length, 'почётных шершней', 'gold'], [S.citizens.filter((c) => c.score <= 0).length, 'агентов', 'red']]));
    this.last = S;
    const ranked = [...S.citizens].sort((a, b) => b.score - a.score);
    const rows = ranked
      .map((c, i) => ({ c, place: i + 1 }))
      .filter(({ c }) => !this.query || c.nick.toLowerCase().includes(this.query))
      .map(({ c, place }) => [
        place,
        `${person(c.nick, { role: c.role, agent: Boolean(c.agent), sub: c.agent ? 'Агент дестабилизации' : '' })}`,
        esc(ROLES[c.role]),
        rankBadge(c.score),
        `<span class="${scoreClass(c.score)}">${c.score}</span>`,
      ]);
    fill(root, 'rating', rows.length ? table(COLUMNS, rows, { className: 'rating' }) : '<div class="empty">Сведения не найдены.</div>');

    fill(root, 'log', list(S.replog.slice(0, 30), (l) => docRow({
      no: `<span class="${deltaClass(l.delta)}">${signed(l.delta)}</span>`,
      date: l.t,
      body: `<h3>${esc(l.nick)}</h3><p class="text">${esc(l.reason)}</p>`,
    }), 'Изменения не вносились.'));

    fillSelect(root, 'citizens', options(S.citizens.map((c) => [c.id, c.nick])));
  },
};
