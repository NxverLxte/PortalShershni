/** Вход и заявление о приёме в гражданство. */
import { GENDERS } from '../../core/constants.js';
import { pageHead } from '../ui/components.js';
import { login, register } from '../store.js';
import { toast } from '../ui/toast.js';
import { formError } from '../ui/interactions.js';
import { esc, formData } from '../utils.js';

function selectTab(root, name) {
  for (const btn of root.querySelectorAll('[role=tab]')) btn.setAttribute('aria-selected', String(btn.dataset.tab === name));
  for (const panel of root.querySelectorAll('[role=tabpanel]')) panel.hidden = panel.dataset.tab !== name;
}

/** Ссылки «Получить гражданство» открывают сразу вкладку регистрации. */
let wantRegister = false;
document.addEventListener('click', (e) => {
  if (!e.target.closest('[data-register]')) return;
  wantRegister = true;
  // Если раздел «Вход» уже открыт, переход по ссылке не произойдёт — переключаем вкладку сразу
  const root = document.querySelector('[data-view="vhod"]');
  if (root) {
    selectTab(root, 'register');
    wantRegister = false;
  }
});

async function submit(form, fn) {
  const button = form.querySelector('button[type=submit]');
  button.disabled = true;
  formError(form, '');
  try {
    await fn(formData(form));
  } catch (err) {
    formError(form, err.message);
  } finally {
    button.disabled = false;
  }
}

export default {
  mount(root) {
    root.innerHTML = `
      ${pageHead({ eyebrow: 'Личный кабинет гражданина', title: 'Вход на портал' })}
      <section class="band"><div class="in auth">
        <div class="tabs" role="tablist">
          <button type="button" role="tab" data-tab="login" aria-selected="true">Вход</button>
          <button type="button" role="tab" data-tab="register" aria-selected="false">Заявление о приёме в гражданство</button>
        </div>

        <form class="form" role="tabpanel" data-tab="login" id="form-login">
          <label>Логин<input name="login" required autocomplete="username" autocapitalize="off"></label>
          <label>Пароль<input name="password" type="password" required autocomplete="current-password"></label>
          <button type="submit">Войти</button>
        </form>

        <form class="form" role="tabpanel" data-tab="register" id="form-register" hidden>
          <label>Логин (латинские буквы, цифры, знаки _ . -)<input name="login" required minlength="3" maxlength="32" pattern="[A-Za-z0-9_.\\-]{3,32}" autocomplete="username" autocapitalize="off"></label>
          <label>Пароль (не менее 6 символов)<input name="password" type="password" required minlength="6" maxlength="100" autocomplete="new-password"></label>
          <label>Имя на сервере Discord<input name="nick" required maxlength="40"></label>
          <label>Роль на сервере<select name="gender">${GENDERS.map((g) => `<option>${esc(g)}</option>`).join('')}</select></label>
          <label class="check"><input type="checkbox" required>Обязуюсь соблюдать Конституцию ШЕРШНЕЙ</label>
          <button type="submit">Подать заявление</button>
          <p class="note">Заявление рассматривается Президентом. Вход на портал возможен после принятия в гражданство. Порядок хранения сведений — в разделе <a href="#dannye">«Обработка данных»</a>.</p>
        </form>
      </div></section>`;

    for (const btn of root.querySelectorAll('[role=tab]')) btn.addEventListener('click', () => selectTab(root, btn.dataset.tab));
    if (wantRegister) selectTab(root, 'register');
    wantRegister = false;

    const loginForm = root.querySelector('#form-login');
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      submit(loginForm, async (data) => {
        await login(data);
        loginForm.reset();
        location.hash = 'glavnaya';
        toast('Вход выполнен');
      });
    });

    const regForm = root.querySelector('#form-register');
    regForm.addEventListener('submit', (e) => {
      e.preventDefault();
      submit(regForm, async (data) => {
        const { first } = await register(data);
        regForm.reset();
        selectTab(root, 'login');
        toast(first
          ? 'Вы зарегистрированы как Президент. Выполните вход.'
          : 'Заявление принято. Вход будет доступен после принятия в гражданство.', { ms: 7000 });
      });
    });
  },

  /** Повторный переход на «Вход» по ссылке «Получить гражданство» переключает вкладку. */
  update(root) {
    if (wantRegister) selectTab(root, 'register');
    wantRegister = false;
  },
};
