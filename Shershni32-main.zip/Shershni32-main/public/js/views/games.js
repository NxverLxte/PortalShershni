/**
 * Раздел «Развлечения»: игры сообщества (Мафия, Шпион и др.).
 * Пока только витрина; механика игр будет добавлена отдельными разделами.
 */
import { pageHead, tag } from '../ui/components.js';
import { GAMES, GAME_STATUS } from '../content/games.js';
import { esc } from '../utils.js';

function card(game) {
  const [label, tone] = GAME_STATUS[game.status] || GAME_STATUS.soon;
  const inner = `
    <div class="game__top">
      <svg viewBox="0 0 24 24" aria-hidden="true">${game.icon}</svg>
      ${tag(label, tone)}
    </div>
    <b>${esc(game.title)}</b>
    <span>${esc(game.text)}</span>
    ${game.players ? `<em class="game__meta">${esc(game.players)}</em>` : ''}`;
  return game.status === 'live' && game.href
    ? `<a class="service game" href="${esc(game.href)}">${inner}</a>`
    : `<article class="service game is-disabled">${inner}</article>`;
}

export default {
  mount(root) {
    root.innerHTML = `
      ${pageHead({
        crumb: 'Развлечения',
        title: 'Развлечения',
        lead: 'Досуговые мероприятия граждан ШЕРШНЕЙ: ролевые и настольные игры, проводимые в голосовых каналах сервера.',
      })}
      <section class="band"><div class="in">
        <div class="section-head">
          <div><div class="eyebrow">Игры сообщества</div><h2>Перечень игр</h2></div>
          <p>Правила и порядок проведения игр будут опубликованы при их запуске на портале.</p>
        </div>
        <div class="services games">${GAMES.map(card).join('')}</div>
      </div></section>`;
  },
};
