/** Структура управления и сведения о замещении должностей. */
import { headStats, pageHead, tag } from '../ui/components.js';
import { fill } from '../ui/dom.js';
import { ORGANS } from '../content/organs.js';
import { esc } from '../utils.js';
import { person } from '../ui/people.js';

function card(organ, holders, head) {
  const holder = holders.length
    ? `<div class="organ__holder">${holders.map((h) => person(h.nick, { role: h.role, sub: '' })).join('')}</div>`
    : `<div class="organ__holder">${tag('Должность вакантна')}</div>`;
  const body = `<div class="eyebrow">${esc(organ.kind)}</div><h3>${esc(organ.name)}</h3>${holder}<p class="text">${esc(organ.text)}</p>`;
  return head
    ? `<article class="organ organ--head"><img src="img/gerb-sm.png" alt="" width="140" height="155"><div>${body}</div></article>`
    : `<article class="organ">${body}</article>`;
}

export default {
  mount(root) {
    root.innerHTML = `
      ${pageHead({
        crumb: 'Структура управления',
        title: 'Структура управления',
        lead: 'Структура управления сообществом в соответствии с Конституцией и сведения о замещении должностей.',
      })}
      <section class="band"><div class="in organs" data-region="organs"></div></section>`;
  },

  update(root, S) {
    const filled = ORGANS.filter((o) => S.officials.some((x) => x.role === o.role)).length;
    fill(root, 'head', headStats([[filled, 'органов сформировано', 'gold'], [ORGANS.length - filled, 'вакантно']]));
    fill(root, 'organs', ORGANS.map((o, i) => card(o, S.officials.filter((x) => x.role === o.role), i === 0)).join(''));
  },
};
