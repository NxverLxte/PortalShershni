/** Законодательство: действующие законы (видны всем) и законопроекты (гражданам). */
import { applyFilter, bindFilters, filterShell, filterTabs, isFiltered } from '../ui/filters.js';
import { BILL_STATUS, BILL_CONGRESS_STATUSES } from '../../core/constants.js';
import { controls, deleteButton, docRow, editButton, empty, field, list, meta, metaItem, pageHead, sectionTitle, statusSelect, statusTag, steps, headStats } from '../ui/components.js';
import { fill } from '../ui/dom.js';
import { can } from '../store.js';
import { esc, pad } from '../utils.js';

function billControls(x) {
  const sign = can('bill.sign');
  const stage = can('bill.stage');
  if (!sign && !stage) return '';
  return controls(
    statusSelect('bill.stage', { id: x.id }, BILL_STATUS, x.status, { allowed: sign ? null : BILL_CONGRESS_STATUSES, label: 'Стадия' }),
    sign && editButton(x.res ? 'Изменить заключение' : 'Заключение Президента', 'bill.conclusion', { id: x.id }, { value: x.res }),
    can('bill.manage') && deleteButton('bill.delete', { id: x.id }),
  );
}

const billRow = (x) => docRow({
  no: `№ ЗП-${pad(x.no)}`,
  date: x.t,
  body: `
    ${meta(statusTag(BILL_STATUS, x.status), metaItem(`Инициатор: ${x.who}`))}
    <h3>${esc(x.title)}</h3>
    ${steps(x.status)}
    ${field('Пояснительная записка', x.note)}
    ${field('Текст законопроекта', x.text)}
    ${field('Заключение Президента', x.res, { gold: true })}
    ${billControls(x)}`,
});

const lawRow = (x) => docRow({
  no: `Закон № ${x.no}`,
  date: x.signedAt || x.t,
  body: `<h3>${esc(x.title)}</h3><p class="text">${esc(x.text)}</p>`,
});

export default {
  mount(root) {
    bindFilters(root, this);
    root.innerHTML = `
      ${pageHead({
        crumb: 'Законодательство',
        title: 'Законодательство',
        lead: 'Законы принимаются Конгрессом простым большинством голосов при наличии кворума (ст. 21.2) и вступают в силу после подписания Президентом (ст. 35). Президент вправе отклонить закон (ст. 12.4).',
      })}
      <section class="band"><div class="in">
        ${sectionTitle('Действующие законы')}
        <div data-region="laws"></div>
      </div></section>

      <section class="band band--flush"><div class="in split">
        <div>${sectionTitle('Законопроекты')}<div data-auth="me">${filterShell('Поиск по законопроектам')}</div><div data-region="bills"></div></div>
        <div class="sticky" data-auth="me">
          <form class="form" data-action="bill.add" data-success="Законопроект зарегистрирован">
            <h2>Внесение законопроекта</h2>
            <p class="note">Законопроект регистрируется и направляется на рассмотрение Конгресса. До формирования Конгресса рассматривается Президентом.</p>
            <label>Наименование законопроекта<input name="title" required maxlength="200" placeholder="О порядке …"></label>
            <label>Пояснительная записка<textarea name="note" required placeholder="Цель и обоснование принятия закона"></textarea></label>
            <label>Текст законопроекта<textarea name="text" required rows="10" placeholder="Статья 1. …"></textarea></label>
            <label class="check"><input type="checkbox" required>Подтверждаю, что законопроект не противоречит Конституции ШЕРШНЕЙ</label>
            <button type="submit">Внести законопроект</button>
          </form>
        </div>
      </div></section>`;
  },

  update(root, S) {
    fill(root, 'head', headStats([[S.laws.length, 'действующих законов', 'gold'], S.me && [S.bills.filter((b) => ['new', 'review', 'passed'].includes(b.status)).length, 'законопроектов на рассмотрении']]));
    fill(root, 'laws', list(S.laws, lawRow, 'Действующих законов нет.'));
    if (S.me) fill(root, 'tabs', filterTabs(BILL_STATUS, S.bills, this.filter));
    fill(root, 'bills', S.me
      ? list(applyFilter(S.bills, this.filter, { text: (x) => `${x.title} ${x.note} ${x.text} ${x.who}` }), billRow, isFiltered(this.filter) ? 'Ничего не найдено. Измените условия поиска.' : 'Законопроекты не вносились.')
      : empty('Реестр законопроектов и законодательная инициатива доступны гражданам после <a href="#vhod">входа в личный кабинет</a>.'));
  },
};
