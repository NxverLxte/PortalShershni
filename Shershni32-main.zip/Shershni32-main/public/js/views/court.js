/** Судебная власть: реестр дел и исковое заявление (ст. 32–33). */
import { applyFilter, bindFilters, filterShell, filterTabs, isFiltered } from '../ui/filters.js';
import { CASE_CATEGORIES, CASE_STATUS } from '../../core/constants.js';
import { controls, deleteButton, docRow, editButton, field, list, meta, metaItem, options, pageHead, sectionTitle, statusSelect, statusTag, headStats } from '../ui/components.js';
import { fill, fillSelect } from '../ui/dom.js';
import { can } from '../store.js';
import { esc, pad } from '../utils.js';

const row = (x) => docRow({
  no: `Дело № Ш-${pad(x.no)}/${new Date(x.t).getFullYear()}`,
  date: x.t,
  body: `
    ${meta(statusTag(CASE_STATUS, x.status), metaItem(x.cat), metaItem(x.art))}
    <h3>Истец ${esc(x.who)}, ответчик ${esc(x.vs)}</h3>
    ${field('Обстоятельства дела', x.text)}
    ${field('Исковые требования', x.demand)}
    ${field('Решение суда', x.res, { gold: true })}
    ${can('case.judge') ? controls(
      statusSelect('case.status', { id: x.id }, CASE_STATUS, x.status),
      editButton(x.res ? 'Изменить решение' : 'Вынести решение', 'case.decision', { id: x.id }, { value: x.res, placeholder: 'Суд, рассмотрев материалы дела, решил: …' }),
      can('case.delete') && deleteButton('case.delete', { id: x.id }),
    ) : ''}`,
});

export default {
  mount(root) {
    bindFilters(root, this);
    root.innerHTML = `
      ${pageHead({
        crumb: 'Судебная власть',
        title: 'Судебная власть',
        lead: 'Правосудие осуществляет Министр юстиции (ст. 33). Штрафы не применяются (ст. 32.2); меры, ограничивающие права гражданина, применяются только по результатам судебного рассмотрения (ст. 32.5).',
      })}
      <section class="band"><div class="in split">
        <div>${sectionTitle('Реестр судебных дел')}${filterShell('Поиск по сторонам и обстоятельствам')}<div data-region="list"></div></div>
        <div class="sticky">
          <form class="form" data-action="case.add" data-success="Исковое заявление принято к производству">
            <h2>Исковое заявление</h2>
            <label>Ответчик<select name="defendant" required data-options="defendants"></select></label>
            <label>Категория спора<select name="cat">${CASE_CATEGORIES.map((c) => `<option>${esc(c)}</option>`).join('')}</select></label>
            <label>Нарушенная норма (при наличии)<input name="art" maxlength="40" placeholder="Например: ст. 8.3"></label>
            <label>Обстоятельства дела<textarea name="text" required placeholder="Изложите обстоятельства, на которых основаны требования"></textarea></label>
            <label>Исковые требования<textarea name="demand" required placeholder="Прошу суд …"></textarea></label>
            <label class="check"><input type="checkbox" required>Подтверждаю достоверность изложенных сведений</label>
            <button type="submit">Подать исковое заявление</button>
          </form>
        </div>
      </div></section>`;
  },

  update(root, S) {
    fill(root, 'head', headStats([[S.cases.filter((c) => c.status === 'new' || c.status === 'hearing').length, 'дел в производстве'], [S.cases.filter((c) => c.status === 'decided').length, 'решений вынесено', 'gold']]));
    fill(root, 'tabs', filterTabs(CASE_STATUS, S.cases, this.filter));
    fill(root, 'list', list(applyFilter(S.cases, this.filter, { text: (x) => `${x.who} ${x.vs} ${x.cat} ${x.art} ${x.text} ${x.demand}` }), row, isFiltered(this.filter) ? 'Ничего не найдено. Измените условия поиска.' : 'Дела в производстве отсутствуют.'));
    const others = S.citizens.filter((c) => c.id !== S.me.id).map((c) => [c.id, c.nick]);
    fillSelect(root, 'defendants', others.length ? options(others) : '<option value="">Нет других граждан</option>');
  },
};
