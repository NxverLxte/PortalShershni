/** Главная страница: полноэкранная обложка, сводка, услуги, акты и законы. */
import { docRow, empty, sectionTitle } from '../ui/components.js';
import { fill } from '../ui/dom.js';
import { SERVICES } from '../content/services.js';
import { POSTS, BILL_STATUS, CASE_STATUS } from '../../core/constants.js';
import { esc, formatDate, percent, plural } from '../utils.js';

/** Карточка ленты «Сейчас на портале». */
const nowCard = ({ href, kind, live = false, title, text, progress, action }) => `
  <a class="now-card${live ? ' now-card--live' : ''}" href="${href}">
    <div class="now-card__kind">${live ? '<span class="live-dot" aria-hidden="true"></span>' : ''}${esc(kind)}</div>
    <h3>${esc(title)}</h3>
    ${text ? `<p>${esc(text)}</p>` : ''}
    ${progress !== undefined ? `<div class="progress"><i style="width:${progress}%"></i></div>` : ''}
    <em>${esc(action)}</em>
  </a>`;

function nowCards(S) {
  const cards = [];
  if (S.me) {
    const voters = S.citizens.filter((c) => !c.agent).length;
    for (const e of S.elections.filter((x) => x.status === 'open')) {
      cards.push({
        href: '#vybory', kind: 'Идёт голосование', live: true,
        title: `Выборы: ${POSTS[e.post]}`,
        text: `Проголосовало ${e.turnout} из ${voters}`,
        progress: percent(e.turnout, voters),
        action: e.myVote ? 'Ваш голос учтён' : 'Проголосовать',
      });
    }
    const rooms = S.spy.rooms;
    if (rooms.length) {
      const players = rooms.reduce((n, r) => n + r.players.length, 0);
      const playing = rooms.some((r) => r.status === 'playing');
      cards.push({
        href: '#shpion', kind: playing ? 'Идёт игра' : 'Набор игроков', live: true,
        title: 'Шпион',
        text: `${rooms.length} ${plural(rooms.length, ['комната', 'комнаты', 'комнат'])} · ${players} ${plural(players, ['игрок', 'игрока', 'игроков'])}`,
        action: 'Присоединиться',
      });
    }
    if (S.me.perms.includes('users.manage')) {
      const pending = (S.accounts || []).filter((u) => u.status === 'pending').length;
      if (pending) cards.push({ href: '#admin', kind: 'Требует решения', live: true, title: 'Заявления о приёме в гражданство', text: `Ожидают рассмотрения: ${pending}`, action: 'Рассмотреть' });
    }
    const toSign = S.bills.find((b) => b.status === 'passed');
    const inWork = S.bills.find((b) => b.status === 'review' || b.status === 'new');
    const bill = toSign || inWork;
    if (bill) cards.push({ href: '#zakony', kind: toSign ? 'Ожидает подписания' : 'Законопроект', title: bill.title, text: BILL_STATUS[bill.status], action: 'Открыть' });
    const decided = S.cases.find((c) => c.status === 'decided');
    const hearing = S.cases.find((c) => c.status === 'hearing' || c.status === 'new');
    const kase = decided || hearing;
    if (kase) cards.push({ href: '#sud', kind: decided ? 'Решение суда' : 'Судебное разбирательство', title: `Истец ${kase.who}, ответчик ${kase.vs}`, text: CASE_STATUS[kase.status], action: 'Подробнее' });
  }
  const decree = S.decrees[0];
  if (decree) cards.push({ href: '#ukazy', kind: `${decree.kind} № ${decree.no}`, title: decree.title, text: formatDate(decree.t), action: 'Читать' });
  const law = S.laws[0];
  if (law && cards.length < 6) cards.push({ href: '#zakony', kind: `Закон № ${law.no}`, title: law.title, text: `Подписан ${formatDate(law.signedAt || law.t)}`, action: 'Читать' });
  return cards.slice(0, 6);
}

const actRow = (x, href) =>
  docRow({ no: `${esc(x.kind || 'Закон')} № ${x.no}`, date: x.signedAt || x.t, body: `<h3><a href="${href}">${esc(x.title)}</a></h3>` });

/** Значение сводки: число крупно, текст — помельче. */
const stat = (value) => {
  const text = String(value);
  return /^[\d—]+$/.test(text) ? `<strong>${esc(text)}</strong>` : `<strong class="is-text">${esc(text)}</strong>`;
};

export default {
  mount(root) {
    root.innerHTML = `
      <section class="hero">
        <img class="hero__emblem" src="img/gerb.png" alt="" width="520" height="575">
        <div class="in hero__content">
          <div class="hero__copy">
            <div class="eyebrow">Официальный портал сообщества</div>
            <h1>Портал <span>ШЕРШНЕЙ</span></h1>
            <p>Акты Президента, законодательство, правосудие и выборы — на едином портале сообщества.</p>
            <div class="btn-row">
              <a class="btn btn--arrow" href="#sud">Подать исковое заявление</a>
              <a class="btn btn--ghost" href="#zakony">Внести законопроект</a>
            </div>
          </div>
          <div class="stats">
            <div data-region="president"></div>
            <div data-region="congress"></div>
            <div data-region="citizens"></div>
            <div data-region="laws-count"></div>
            <div data-region="cases-count"></div>
          </div>
        </div>
      </section>

      <section class="band now" data-now><div class="in">
        <div class="section-head">
          <div><div class="eyebrow"><span class="live-dot" aria-hidden="true"></span>Сейчас на портале</div><h2>Актуальное</h2></div>
          <p>Открытые голосования, игры, документы на рассмотрении и последние акты.</p>
        </div>
        <div class="now-grid" data-region="now"></div>
      </div></section>

      <section class="band"><div class="in">
        <div class="section-head">
          <div><div class="eyebrow">Для граждан</div><h2>Услуги портала</h2></div>
          <p>Обращения регистрируются в реестрах портала и рассматриваются уполномоченными должностными лицами.</p>
        </div>
        <div class="services">
          ${SERVICES.map((s) => `
            <a class="service" href="${s.href}">
              <svg viewBox="0 0 24 24" aria-hidden="true">${s.icon}</svg>
              <b>${esc(s.title)}</b>
              <span>${esc(s.text)}</span>
              <em>Перейти</em>
            </a>`).join('')}
        </div>
      </div></section>

      <section class="band band--flush"><div class="in grid-2">
        <div>${sectionTitle('Акты Президента', { href: '#ukazy', label: 'Все акты' })}<div data-region="decrees"></div></div>
        <div>${sectionTitle('Действующие законы', { href: '#zakony', label: 'Законодательство' })}<div data-region="laws"></div></div>
      </div></section>

      <section class="band cta" data-auth="guest">
        <img src="img/gerb-sm.png" alt="" width="140" height="155">
        <div class="eyebrow">Приём в гражданство</div>
        <h2>Станьте гражданином</h2>
        <p>Подайте заявление на портале. После принятия в гражданство Президентом откроются реестры, суд, законодательная инициатива и голосование.</p>
        <div class="btn-row">
          <a class="btn btn--arrow" href="#vhod" data-register>Подать заявление</a>
          <a class="btn btn--ghost" href="#konstitutsiya">Конституция</a>
        </div>
      </section>`;
  },

  update(root, S) {
    const president = S.officials.find((o) => o.role === 'president');
    const items = {
      president: [president ? president.nick : 'Исполняет полномочия', 'Президент'],
      congress: S.officials.some((o) => o.role === 'congress')
        ? [S.officials.filter((o) => o.role === 'congress').length, 'Членов Конгресса']
        : ['Не сформирован', 'Конгресс'],
      citizens: [S.me ? S.citizens.length : '—', 'Граждан'],
      'laws-count': [S.laws.length, 'Действующих законов'],
      'cases-count': [S.me ? S.cases.filter((c) => c.status === 'new' || c.status === 'hearing').length : '—', 'Дел в производстве'],
    };
    for (const [key, [value, label]] of Object.entries(items)) fill(root, key, `${stat(value)}<span>${esc(label)}</span>`);

    const cards = nowCards(S);
    root.querySelector('[data-now]').hidden = !cards.length;
    fill(root, 'now', cards.map(nowCard).join(''));

    fill(root, 'decrees', S.decrees.length ? S.decrees.slice(0, 4).map((x) => actRow(x, '#ukazy')).join('') : empty('Акты не опубликованы.'));
    fill(root, 'laws', S.laws.length ? S.laws.slice(0, 4).map((x) => actRow({ ...x, kind: 'Закон' }, '#zakony')).join('') : empty('Действующих законов нет.'));
  },
};
