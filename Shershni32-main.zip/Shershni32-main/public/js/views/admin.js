/** Администрирование: заявления о приёме в гражданство и учётные записи (только Президент). */
import { ASSIGNABLE_ROLES, ROLES, USER_STATUS } from '../../core/constants.js';
import { actionButton, deleteButton, docRow, editButton, list, meta, metaItem, pageHead, sectionTitle, statusSelect, statusTag, table } from '../ui/components.js';
import { fill } from '../ui/dom.js';
import { esc } from '../utils.js';
import { person } from '../ui/people.js';

const COLUMNS = [{ label: 'Гражданин' }, { label: 'Логин' }, { label: 'Роль' }, { label: 'Должность' }, { label: 'Доступ' }, { label: 'Действия' }];
const ASSIGNABLE = Object.fromEntries(ASSIGNABLE_ROLES.map((r) => [r, ROLES[r]]));

const pendingRow = (u) => docRow({
  no: 'Заявление',
  date: u.since,
  body: `
    <div class="mb-s">${person(u.nick, { sub: 'Заявление о приёме в гражданство', size: 'md' })}</div>
    ${meta(metaItem(`Логин: ${u.login}`), metaItem(`Роль на сервере: ${u.gender}`))}
    <div class="btn-row mt-s">
      ${actionButton('Принять в гражданство', 'user.status', { uid: u.id, status: 'approved' }, { primary: true })}
      ${actionButton('Отказать', 'user.status', { uid: u.id, status: 'rejected' }, { confirm: 'Подтвердить отказ' })}
    </div>`,
});

function accountRow(u, me) {
  const self = u.id === me.id;
  return [
    person(u.nick, { role: u.status === 'approved' ? u.role : 'citizen', sub: '' }),
    esc(u.login),
    esc(u.gender),
    self ? esc(ROLES[u.role]) : statusSelect('user.role', { uid: u.id }, ASSIGNABLE, u.role, { name: 'role', label: 'Должность' }),
    self ? statusTag(USER_STATUS, u.status) : statusSelect('user.status', { uid: u.id }, USER_STATUS, u.status, { label: 'Доступ' }),
    self ? '' : `<div class="btn-row">${editButton('Новый пароль', 'user.password', { uid: u.id }, { kind: 'password', placeholder: 'Не менее 6 символов' })}${deleteButton('user.delete', { uid: u.id })}</div>`,
  ];
}

export default {
  mount(root) {
    root.innerHTML = `
      ${pageHead({
        crumb: 'Администрирование',
        title: 'Администрирование',
        lead: 'Рассмотрение заявлений о приёме в гражданство, назначение на должности и управление доступом к порталу. Заблокированные и получившие отказ не могут войти на портал.',
      })}
      <section class="band"><div class="in">
        ${sectionTitle('Заявления о приёме в гражданство')}
        <div data-region="pending"></div>
        <div class="mt-l">${sectionTitle('Учётные записи')}</div>
        <div data-region="accounts"></div>
        <p class="note mt-s">Новый пароль сообщите гражданину лично. После смены пароля все его сеансы завершаются.</p>
      </div></section>`;
  },

  update(root, S) {
    const accounts = S.accounts || [];
    fill(root, 'pending', list(accounts.filter((u) => u.status === 'pending'), pendingRow, 'Новые заявления отсутствуют.'));
    fill(root, 'accounts', table(COLUMNS, accounts.map((u) => accountRow(u, S.me))));
  },
};
