/** Заглушка для разделов, доступных только гражданам. */
export default {
  mount(root) {
    root.innerHTML = `
      <section class="band gate-band"><div class="in gate">
        <img src="img/gerb-sm.png" alt="" width="140" height="155">
        <h1>Раздел доступен гражданам</h1>
        <p class="lead">Реестры и услуги портала доступны гражданам ШЕРШНЕЙ после входа в личный кабинет.</p>
        <div class="btn-row">
          <a class="btn" href="#vhod">Войти</a>
          <a class="btn btn--ghost" href="#vhod" data-register>Заявление о приёме в гражданство</a>
        </div>
      </div></section>`;
  },
};
