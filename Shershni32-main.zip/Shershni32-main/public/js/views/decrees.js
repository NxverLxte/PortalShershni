/** Акты Президента. */
import { applyFilter, bindFilters, filterShell, filterTabs, isFiltered } from '../ui/filters.js';
import { ACT_KINDS } from '../../core/constants.js';
import { controls, deleteButton, docRow, list, pageHead, sectionTitle, headStats } from '../ui/components.js';
import { fill } from '../ui/dom.js';
import { can } from '../store.js';
import { esc } from '../utils.js';

export default {
  mount(root) {
    bindFilters(root, this);
    root.innerHTML = `
      ${pageHead({
        crumb: 'Указы',
        title: 'Акты Президента',
        lead: 'Указы Президента обладают силой закона. Вопросы, не урегулированные Конституцией, разрешаются указами Президента (ст. 40.2).',
      })}
      <section class="band"><div class="in split">
        <div>${sectionTitle('Реестр актов')}${filterShell('Поиск по наименованию и тексту')}<div data-region="list"></div></div>
        <div class="sticky" data-perm="decree.manage">
          <form class="form" data-action="decree.add" data-success="Акт подписан и опубликован">
            <h2>Издание акта</h2>
            <label>Вид акта<select name="kind">${ACT_KINDS.map((k) => `<option>${esc(k)}</option>`).join('')}</select></label>
            <label>Наименование <input name="title" required maxlength="200" placeholder="О …"></label>
            <label>Текст акта<textarea name="text" required rows="10" placeholder="Руководствуясь статьёй … Конституции, постановляю:"></textarea></label>
            <button type="submit">Подписать и опубликовать</button>
          </form>
        </div>
      </div></section>`;
  },

  update(root, S) {
    fill(root, 'head', headStats([[S.decrees.length, 'актов опубликовано'], [S.decrees.filter((d) => Date.now() - d.t < 30 * 864e5).length, 'за последние 30 дней', 'gold']]));
    const manage = can('decree.manage');
    const kinds = Object.fromEntries(S.decrees.map((d) => [d.kind, d.kind]));
    fill(root, 'tabs', filterTabs(kinds, S.decrees, this.filter, (x) => x.kind));
    const shown = applyFilter(S.decrees, this.filter, { status: (x) => x.kind, text: (x) => `${x.title} ${x.text}` });
    fill(root, 'list', list(shown, (x) => docRow({
      no: `${esc(x.kind)} № ${x.no}`,
      date: x.t,
      body: `<h3>${esc(x.title)}</h3><p class="text">${esc(x.text)}</p>${manage ? controls(deleteButton('decree.delete', { id: x.id })) : ''}`,
    }), isFiltered(this.filter) ? 'Ничего не найдено. Измените условия поиска.' : 'Акты не опубликованы.'));
  },
};
