/** Предложения поправок к Конституции (ст. 39). */
import { applyFilter, bindFilters, filterShell, filterTabs, isFiltered } from '../ui/filters.js';
import { AMENDMENT_STATUS } from '../../core/constants.js';
import { controls, deleteButton, docRow, editButton, field, list, meta, metaItem, pageHead, sectionTitle, statusSelect, statusTag, headStats } from '../ui/components.js';
import { fill } from '../ui/dom.js';
import { can } from '../store.js';
import { esc, pad } from '../utils.js';

const row = (x) => docRow({
  no: `№ П-${pad(x.no)}`,
  date: x.t,
  body: `
    ${meta(statusTag(AMENDMENT_STATUS, x.status), metaItem(`Заявитель: ${x.who}`))}
    <h3>О внесении изменений в ${esc(x.art)}</h3>
    ${field('Предлагаемая редакция', x.text)}
    ${field('Обоснование', x.why)}
    ${field('Резолюция Президента', x.res, { gold: true })}
    ${can('amendment.review') ? controls(
      statusSelect('amendment.status', { id: x.id }, AMENDMENT_STATUS, x.status),
      editButton(x.res ? 'Изменить резолюцию' : 'Резолюция', 'amendment.resolution', { id: x.id }, { value: x.res }),
      deleteButton('amendment.delete', { id: x.id }),
    ) : ''}`,
});

export default {
  mount(root) {
    bindFilters(root, this);
    root.innerHTML = `
      ${pageHead({
        crumb: 'Поправки к Конституции',
        title: 'Предложения поправок к Конституции',
        lead: 'Поправки к Конституции вносятся Президентом (ст. 39). Гражданин вправе направить предложение о поправке; предложение регистрируется и передаётся на рассмотрение Президенту.',
      })}
      <section class="band"><div class="in split">
        <div>${sectionTitle('Реестр предложений')}${filterShell('Поиск по статье и тексту')}<div data-region="list"></div></div>
        <div class="sticky">
          <form class="form" data-action="amendment.add" data-success="Предложение зарегистрировано">
            <h2>Предложение о поправке</h2>
            <label>Статья Конституции<input name="art" required maxlength="40" placeholder="Например: ст. 21.2"></label>
            <label>Предлагаемая редакция<textarea name="text" required></textarea></label>
            <label>Обоснование<textarea name="why"></textarea></label>
            <button type="submit">Направить предложение</button>
          </form>
        </div>
      </div></section>`;
  },

  update(root, S) {
    fill(root, 'head', headStats([[S.amendments.filter((a) => a.status === 'new' || a.status === 'review').length, 'предложений на рассмотрении'], [S.amendments.filter((a) => a.status === 'accepted').length, 'внесено в Конституцию', 'gold']]));
    fill(root, 'tabs', filterTabs(AMENDMENT_STATUS, S.amendments, this.filter));
    fill(root, 'list', list(applyFilter(S.amendments, this.filter, { text: (x) => `${x.art} ${x.text} ${x.why} ${x.who}` }), row, isFiltered(this.filter) ? 'Ничего не найдено. Измените условия поиска.' : 'Предложения не поступали.'));
  },
};
