/**
 * Игра «Шпион»: комнаты, карточки раунда, управление ведущего, редактор тем.
 * Раздел обновляется каждые 2,5 секунды (poll), чтобы раунды начинались у всех сразу.
 */
import { actionButton, editButton, deleteButton, empty, meta, metaItem, options, pageHead, sectionTitle, tag, headStats } from '../ui/components.js';
import { fill, fillSelect } from '../ui/dom.js';
import { can } from '../store.js';
import { esc, plural } from '../utils.js';
import { avatar } from '../ui/people.js';

const STATUS = { lobby: ['Набор игроков', ''], playing: ['Идёт раунд', 'ok'], revealed: ['Раунд завершён', ''] };

const listOptions = (lists, selected) => options(lists.map((l) => [l.id, `${l.title} (${l.count})`]), selected);

function settingsForm(room, lists, submitLabel) {
  return `
    <form class="spy-settings" data-action="spy.settings" data-rid="${esc(room.id)}" data-success="Настройки сохранены" data-keep>
      <div class="field-row">
        <label>Тема<select name="listId">${listOptions(lists, room.listId)}</select></label>
        <label>Число шпионов<input name="spies" type="number" min="1" max="10" value="${room.spies}" required></label>
      </div>
      <button type="submit" class="btn--ghost btn--sm">Сохранить настройки</button>
    </form>
    <div class="btn-row mt-s">${actionButton(submitLabel, 'spy.start', { rid: room.id }, { primary: true })}</div>`;
}

function card(room, shown) {
  const c = room.round?.card;
  if (!c) return '<div class="spy-card spy-card--empty"><p class="note">Вы не участвуете в текущем раунде. Дождитесь следующего.</p></div>';
  if (!shown) {
    return `
      <button type="button" class="spy-card spy-card--closed" data-flip>
        <span class="eyebrow">Раунд ${room.round.no}</span>
        <b>Открыть карточку</b>
        <span class="note">Убедитесь, что экран не видят другие игроки</span>
      </button>`;
  }
  return `
    <button type="button" class="spy-card ${c.spy ? 'spy-card--spy' : ''}" data-flip>
      <span class="eyebrow">${c.spy ? 'Ваша роль' : `Тема: ${esc(room.round.listTitle)}`}</span>
      <b>${c.spy ? 'Вы шпион' : esc(c.word)}</b>
      <span class="note">${c.spy ? 'Определите слово по вопросам других игроков и не выдайте себя.' : 'Не называйте слово прямо. Задавайте вопросы и вычислите шпиона.'}</span>
      <span class="spy-card__hide">Скрыть</span>
    </button>`;
}

function myRoom(room, S, view) {
  const me = S.me;
  const host = room.hostId === me.id;
  const [label, tone] = STATUS[room.status];
  const roundKey = `${room.id}:${room.round?.no}`;

  const players = room.players.map((p) => `
    <li>
      <span class="spy-player">${avatar(p.nick, { size: 'sm' })}${esc(p.nick)}${p.id === room.hostId ? ' <small class="gold">ведущий</small>' : ''}${p.id === me.id ? ' <small class="muted">вы</small>' : ''}</span>
      ${host && p.id !== me.id && room.status !== 'playing' ? actionButton('Исключить', 'spy.kick', { rid: room.id, uid: p.id }, { confirm: 'Подтвердить' }) : ''}
    </li>`).join('');

  let stage = '';
  if (room.status === 'lobby') {
    stage = `<div class="spy-stage"><p class="lead">Ожидание начала раунда. Ведущий выбирает тему и число шпионов.</p></div>`;
  } else {
    const r = room.round;
    stage = `
      <div class="spy-stage">
        ${card(room, view.shown === roundKey)}
        <div class="spy-info">
          ${room.status === 'playing'
            ? `<div class="field field--gold"><span>Первым задаёт вопрос</span><p class="text">${esc(r.first)}</p></div>
               <p class="note mt-s">Игроков в раунде: ${r.players}. Шпионов: ${room.spies}. Обсуждение ведётся в голосовом канале.</p>`
            : `<div class="field field--gold"><span>Слово раунда</span><p class="text spy-reveal">${esc(r.reveal.word)}</p></div>
               <div class="field"><span>${r.reveal.spies.length > 1 ? 'Шпионы' : 'Шпион'}</span><p class="text">${r.reveal.spies.map(esc).join(', ')}</p></div>`}
        </div>
      </div>`;
  }

  const controls = host
    ? room.status === 'playing'
      ? `<div class="btn-row">${actionButton('Завершить раунд и раскрыть', 'spy.reveal', { rid: room.id }, { primary: true, confirm: 'Подтвердить раскрытие' })}</div>`
      : settingsForm(room, S.spy.lists, room.status === 'lobby' ? 'Начать раунд' : 'Новый раунд')
    : '';

  return `
    <div class="spy-room">
      <div class="spy-room__head">
        <div>
          <div class="eyebrow">Комната № ${room.no}</div>
          <h2>${esc(room.listTitle)}</h2>
          ${meta(tag(label, tone), metaItem(`Ведущий: ${room.host}`), metaItem(`${room.spies} ${plural(room.spies, ['шпион', 'шпиона', 'шпионов'])}`), room.rounds ? metaItem(`Раундов сыграно: ${room.rounds}`) : '')}
        </div>
        <div class="btn-row">
          ${actionButton('Покинуть комнату', 'spy.leave', { rid: room.id }, { confirm: 'Подтвердить выход' })}
          ${host ? actionButton('Закрыть комнату', 'spy.close', { rid: room.id }, { confirm: 'Подтвердить закрытие', danger: true }) : ''}
        </div>
      </div>
      ${stage}
      <div class="spy-room__foot">
        <div><div class="field"><span>Игроки (${room.players.length})</span></div><ul class="spy-players">${players}</ul></div>
        <div>${controls}</div>
      </div>
    </div>`;
}

const lobbyRow = (room, S) => `
  <article class="spy-lobby">
    <div>
      <h3>Комната № ${room.no} · ${esc(room.listTitle)}</h3>
      ${meta(tag(...STATUS[room.status]), metaItem(`Ведущий: ${room.host}`), metaItem(`Игроков: ${room.players.length}`), metaItem(`${room.spies} ${plural(room.spies, ['шпион', 'шпиона', 'шпионов'])}`))}
    </div>
    <div class="btn-row">
      ${room.status === 'playing' ? '<span class="note">Присоединение после раунда</span>' : actionButton('Присоединиться', 'spy.join', { rid: room.id }, { primary: true })}
      ${can('games.moderate') ? deleteButton('spy.close', { rid: room.id }) : ''}
    </div>
  </article>`;

function listEditor(l, open) {
  return `
    <details class="wordlist"${open ? ' open' : ''} data-list="${esc(l.id)}">
      <summary><b>${esc(l.title)}</b><span class="note">${l.count} ${plural(l.count, ['слово', 'слова', 'слов'])}</span></summary>
      <div class="wordlist__body">
        <form data-action="wordlist.add" data-id="${esc(l.id)}" data-success="Слова добавлены">
          <label>Добавить слова<textarea name="words" rows="4" required placeholder="Каждое слово с новой строки или через запятую"></textarea></label>
          <button type="submit" class="btn--sm mt-s">Добавить</button>
        </form>
        <div class="controls">
          ${editButton('Переименовать тему', 'wordlist.rename', { id: l.id }, { kind: 'text', value: l.title })}
          ${deleteButton('wordlist.delete', { id: l.id })}
        </div>
        <div class="chips">${(l.words || []).map((w) => `<span class="chip">${esc(w)}<button type="button" aria-label="Удалить слово ${esc(w)}" data-action="wordlist.remove" data-id="${esc(l.id)}" data-word="${esc(w)}" data-success="Слово удалено">×</button></span>`).join('') || '<span class="note">В теме нет слов</span>'}</div>
      </div>
    </details>`;
}

export default {
  poll: 2500,

  mount(root) {
    this.shown = null;
    this.openLists = new Set();
    root.innerHTML = `
      ${pageHead({
        crumb: 'Шпион',
        parent: { href: '#razvlecheniya', label: 'Развлечения' },
        title: 'Шпион',
        compact: true,
        lead: 'Все игроки получают одно слово, кроме шпиона. Игроки по очереди задают друг другу вопросы, чтобы вычислить шпиона; шпион пытается понять, о каком слове идёт речь.',
      })}
      <section class="band"><div class="in">
        <div data-part="room" data-region="room" hidden></div>
        <div data-part="lobby" class="split">
          <div>${sectionTitle('Открытые комнаты')}<div data-region="rooms"></div></div>
          <form class="form" data-action="spy.create" data-success="Комната создана">
            <h2>Новая комната</h2>
            <label>Тема<select name="listId" required data-options="spy-lists"></select></label>
            <label>Число шпионов<input name="spies" type="number" min="1" max="10" value="1" required></label>
            <p class="note">Для начала раунда нужно не менее трёх игроков. Мирных игроков должно быть не меньше двух.</p>
            <button type="submit">Создать комнату</button>
          </form>
        </div>
      </div></section>

      <section class="band band--flush"><div class="in split">
        <div>
          ${sectionTitle('Порядок проведения')}
          <ol class="rules">
            <li>Ведущий создаёт комнату, выбирает тему и число шпионов. Остальные игроки присоединяются.</li>
            <li>Ведущий начинает раунд. Каждый игрок открывает свою карточку: слово или отметку «Вы шпион».</li>
            <li>Игроки по очереди задают друг другу вопросы о слове, не называя его. Первого спрашивающего определяет портал.</li>
            <li>Игроки голосуют за того, кого считают шпионом. Шпион вправе в любой момент назвать слово.</li>
            <li>Ведущий завершает раунд: портал раскрывает слово и шпионов. Можно начать новый раунд.</li>
          </ol>
        </div>
        <div data-perm="games.words">
          ${sectionTitle('Темы')}
          <p class="note">Слова вносятся списком: каждое с новой строки или через запятую. Повторы отбрасываются автоматически.</p>
          <div data-region="lists"></div>
          <form class="form mt-m" data-action="wordlist.create" data-success="Тема создана">
            <h2>Новая тема</h2>
            <label>Название<input name="title" required maxlength="200" placeholder="Например: Персонажи фильмов"></label>
            <label>Слова<textarea name="words" rows="6" placeholder="Каждое слово с новой строки или через запятую"></textarea></label>
            <button type="submit">Создать тему</button>
          </form>
        </div>
      </div></section>`;

    root.addEventListener('click', (e) => {
      if (!e.target.closest('[data-flip]')) return;
      const room = this.myRoom;
      const key = room ? `${room.id}:${room.round?.no}` : null;
      this.shown = this.shown === key ? null : key;
      this.update(root, this.last);
    });
    // Запоминаем раскрытые темы, чтобы фоновое обновление их не сворачивало
    root.addEventListener('toggle', (e) => {
      const d = e.target.closest?.('details[data-list]');
      if (!d) return;
      if (d.open) this.openLists.add(d.dataset.list);
      else this.openLists.delete(d.dataset.list);
    }, true);
  },

  update(root, S) {
    fill(root, 'head', headStats([[S.spy.rooms.length, 'открытых комнат'], [S.spy.rooms.reduce((n, r) => n + r.players.length, 0), 'игроков в комнатах', 'gold']]));
    this.last = S;
    const rooms = S.spy.rooms;
    const mine = rooms.find((r) => r.players.some((p) => p.id === S.me.id));
    this.myRoom = mine;

    root.querySelector('[data-part="room"]').hidden = !mine;
    root.querySelector('[data-part="lobby"]').hidden = Boolean(mine);
    fill(root, 'room', mine ? myRoom(mine, S, this) : '');
    fill(root, 'rooms', rooms.length ? rooms.map((r) => lobbyRow(r, S)).join('') : empty('Открытых комнат нет. Создайте комнату и пригласите игроков.'));
    fillSelect(root, 'spy-lists', listOptions(S.spy.lists));

    if (can('games.words')) fill(root, 'lists', S.spy.lists.map((l) => listEditor(l, this.openLists.has(l.id))).join(''));
  },
};
