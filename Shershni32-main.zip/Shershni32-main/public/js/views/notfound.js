/** Страница «Раздел не найден». */
export default {
  mount(root) {
    root.innerHTML = `
      <section class="band gate-band"><div class="in gate">
        <img src="img/gerb-sm.png" alt="" width="140" height="155">
        <div class="eyebrow mt-m">Ошибка 404</div>
        <h1>Раздел не найден</h1>
        <p class="lead">Запрошенный раздел портала отсутствует или был перемещён. Проверьте адрес или воспользуйтесь меню.</p>
        <div class="btn-row">
          <a class="btn" href="#glavnaya">На главную</a>
          <a class="btn btn--ghost" href="#konstitutsiya">Конституция</a>
        </div>
      </div></section>`;
  },
};
