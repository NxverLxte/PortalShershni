/** Изложение Конституции: оглавление по главам, поиск по статьям. */
import { headStats, pageHead } from '../ui/components.js';
import { fill } from '../ui/dom.js';
import { CONSTITUTION } from '../content/constitution.js';
import { esc } from '../utils.js';

const total = CONSTITUTION.reduce((n, c) => n + c.articles.length, 0);

/** Подсветка найденного фрагмента (текст уже экранирован). */
function mark(text, q) {
  const safe = esc(text);
  if (!q) return safe;
  const i = text.toLowerCase().indexOf(q);
  if (i < 0) return safe;
  return `${esc(text.slice(0, i))}<mark>${esc(text.slice(i, i + q.length))}</mark>${esc(text.slice(i + q.length))}`;
}

function render(q) {
  const query = q.trim().toLowerCase();
  let found = 0;
  const html = CONSTITUTION.map((c, ci) => {
    const articles = c.articles.filter(([n, t]) => !query || `${n} ${t}`.toLowerCase().includes(query));
    found += articles.length;
    if (!articles.length) return '';
    return `
      <section class="chapter" id="chapter-${ci}">
        <h3><span>Глава ${ci + 1}</span>${esc(c.chapter)}</h3>
        ${articles.map(([n, t]) => `<div class="article"><b>${mark(n, query)}</b><span>${mark(t, query)}</span></div>`).join('')}
      </section>`;
  }).join('');
  return found ? html : '<div class="empty">Статьи по запросу не найдены.</div>';
}

export default {
  mount(root) {
    root.innerHTML = `
      ${pageHead({
        crumb: 'Конституция',
        title: 'Конституция ШЕРШНЕЙ',
        lead: 'Изложение основных положений Конституции. Официальный текст опубликован на Discord-сервере сообщества и имеет приоритет над настоящим изложением.',
      })}
      <section class="band"><div class="in const-layout">
        <aside class="const-toc">
          <label class="filter-search const-search"><span class="sr-only">Поиск по статьям</span>
            <input type="search" data-const-q placeholder="Поиск по статьям" autocomplete="off">
          </label>
          <nav aria-label="Главы Конституции">
            ${CONSTITUTION.map((c, i) => `<button type="button" class="const-toc__item" data-chapter="${i}"><span>${i + 1}</span>${esc(c.chapter)}</button>`).join('')}
          </nav>
        </aside>
        <div class="const-body" data-region="body"></div>
      </div></section>`;

    fill(root, 'head', headStats([[CONSTITUTION.length, 'глав'], [total, 'статей в изложении', 'gold']]));
    fill(root, 'body', render(''));

    root.querySelector('[data-const-q]').addEventListener('input', (e) => fill(root, 'body', render(e.target.value)));

    // Переход к главе — прокруткой: адрес (#хеш) занят маршрутизатором
    root.querySelector('.const-toc nav').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-chapter]');
      if (!btn) return;
      root.querySelector(`#chapter-${btn.dataset.chapter}`)?.scrollIntoView({ block: 'start' });
    });

    // Подсветка текущей главы в оглавлении
    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver((entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          const i = e.target.id.split('-')[1];
          for (const b of root.querySelectorAll('.const-toc__item')) b.classList.toggle('is-active', b.dataset.chapter === i);
        }
      }, { rootMargin: '-30% 0px -60% 0px' });
      const watch = () => root.querySelectorAll('.chapter').forEach((ch) => io.observe(ch));
      watch();
      root.querySelector('[data-const-q]').addEventListener('input', watch);
    }
  },
};
