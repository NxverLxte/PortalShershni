/*
 * Применяет сохранённое оформление до отрисовки страницы, чтобы не было мигания.
 * Подключается обычным (не модульным) скриптом в <head>: встроенные скрипты запрещены CSP.
 */
(function () {
  try {
    var style = localStorage.getItem('portal-style');
    if (style === 'glass' || style === 'classic') document.documentElement.setAttribute('data-style', style);
  } catch (e) {
    /* хранилище недоступно — остаётся оформление по умолчанию */
  }
})();
