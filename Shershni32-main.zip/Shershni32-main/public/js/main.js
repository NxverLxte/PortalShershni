/**
 * Точка входа интерфейса портала.
 * Порядок: шапка → обработчики → загрузка состояния → раздел → фоновое обновление.
 */
import { refresh, onChange, getState } from './store.js';
import { render, startRouter, currentPoll, ROUTES } from './router.js';
import { renderNav, renderUser, renderDates, installHeader } from './ui/header.js';
import { installInteractions, isBusy } from './ui/interactions.js';
import { toastError } from './ui/toast.js';
import { installStyleSwitch } from './ui/style-switch.js';

const POLL_MS = 20000;

let lastUserKey = '';

onChange((state) => {
  renderUser(state);
  // При входе, выходе или смене должности раздел перемонтируется: меняются доступные формы
  const key = state.me ? `${state.me.id}:${state.me.role}:${state.me.perms.join(',')}` : 'guest';
  const userChanged = key !== lastUserKey;
  lastUserKey = key;
  render({ force: userChanged });
});

async function boot() {
  renderNav(ROUTES);
  renderDates();
  installHeader();
  installInteractions();
  installStyleSwitch();
  startRouter();
  try {
    await refresh();
  } catch (err) {
    document.getElementById('app').innerHTML =
      '<section class="band"><div class="in gate"><h1>Портал временно недоступен</h1><p class="lead">Не удалось связаться с сервером. Обновите страницу через несколько минут.</p></div></section>';
    toastError(err);
    return;
  }

  // Фоновое обновление: новые указы, голоса и решения появляются без перезагрузки.
  // Раздел может попросить обновляться чаще (view.poll) — например, игры.
  let last = Date.now();
  let inFlight = false;
  setInterval(async () => {
    if (inFlight || document.hidden || isBusy() || !getState()) return;
    if (Date.now() - last < (currentPoll() || POLL_MS)) return;
    inFlight = true;
    try {
      await refresh();
    } catch {
      /* сеть недоступна — попробуем позже */
    } finally {
      last = Date.now();
      inFlight = false;
    }
  }, 500);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && !isBusy()) refresh().catch(() => {});
  });
}

boot();
