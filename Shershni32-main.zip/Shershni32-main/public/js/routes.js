/**
 * Разделы портала. Адрес раздела — #id.
 *
 * access:
 *   'public'           — всем
 *   'citizen'          — только вошедшим (иначе показывается заглушка)
 *   'guest'            — только гостям (вошедший переводится в кабинет)
 *   'perm:<полномочие>' — только при наличии полномочия (иначе — на главную)
 *
 * nav: true — раздел в меню-шторке; primary: true — ещё и в шапке на широком экране.
 */
import home from './views/home.js';
import constitution from './views/constitution.js';
import organs from './views/organs.js';
import decrees from './views/decrees.js';
import laws from './views/laws.js';
import amendments from './views/amendments.js';
import court from './views/court.js';
import elections from './views/elections.js';
import reputation from './views/reputation.js';
import agents from './views/agents.js';
import games from './views/games.js';
import spy from './views/spy.js';
import privacy from './views/privacy.js';
import auth from './views/auth.js';
import cabinet from './views/cabinet.js';
import admin from './views/admin.js';
import gate from './views/gate.js';
import notFound from './views/notfound.js';

export const DEFAULT_ROUTE = 'glavnaya';

export const ROUTES = [
  { id: 'glavnaya', title: 'Главная', nav: true, access: 'public', view: home },
  { id: 'konstitutsiya', primary: true, title: 'Конституция', nav: true, access: 'public', view: constitution },
  { id: 'vlast', title: 'Управление', nav: true, access: 'public', view: organs },
  { id: 'ukazy', primary: true, title: 'Указы', nav: true, access: 'public', view: decrees },
  { id: 'zakony', primary: true, title: 'Законодательство', nav: true, access: 'public', view: laws },
  { id: 'popravki', title: 'Поправки', nav: true, access: 'citizen', view: amendments },
  { id: 'sud', primary: true, title: 'Судебная власть', nav: true, access: 'citizen', view: court },
  { id: 'vybory', primary: true, title: 'Выборы', nav: true, access: 'citizen', view: elections },
  { id: 'reputatsiya', title: 'Репутация', nav: true, access: 'citizen', view: reputation },
  { id: 'reestr', title: 'Реестр агентов', nav: true, access: 'citizen', view: agents },
  { id: 'razvlecheniya', title: 'Развлечения', nav: true, access: 'public', view: games },
  { id: 'shpion', title: 'Шпион', access: 'citizen', view: spy },
  { id: 'dannye', title: 'Обработка данных', access: 'public', view: privacy },
  { id: 'vhod', title: 'Вход', access: 'guest', view: auth },
  { id: 'kabinet', title: 'Личный кабинет', access: 'citizen', view: cabinet },
  { id: 'admin', title: 'Администрирование', access: 'perm:users.manage', view: admin },
];

export const NOT_FOUND = { id: 'ne-naideno', title: 'Раздел не найден', access: 'public', view: notFound };

export const GATE = { id: 'gate', title: 'Раздел доступен гражданам', access: 'public', view: gate };

/** Прежние адреса, чтобы старые ссылки продолжали работать. */
export const ALIASES = { kongress: 'vybory' };

export const findRoute = (id) => ROUTES.find((r) => r.id === (ALIASES[id] || id));
