/** Обращения к серверу. Все ошибки приводятся к ApiError с понятным текстом. */

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

async function request(method, path, body) {
  let res;
  try {
    res = await fetch(path, {
      method,
      credentials: 'same-origin',
      headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError('Нет связи с сервером. Проверьте подключение к интернету', 0);
  }
  let data;
  try {
    data = await res.json();
  } catch {
    throw new ApiError('Сервер временно недоступен', res.status);
  }
  if (!res.ok) throw new ApiError(data.error || 'Ошибка при выполнении запроса', res.status);
  return data;
}

export const api = {
  get: (path) => request('GET', path),
  post: (path, body = {}) => request('POST', path, body),
};
