/**
 * Переключатель оформления: «Классика» и «Стекло» (Liquid Glass).
 * Выбор хранится в браузере (localStorage) и применяется до отрисовки скриптом js/theme-init.js.
 */
const KEY = 'portal-style';
const STYLES = ['classic', 'glass'];

export function currentStyle() {
  return document.documentElement.getAttribute('data-style') === 'glass' ? 'glass' : 'classic';
}

function apply(style) {
  if (!STYLES.includes(style)) return;
  document.documentElement.setAttribute('data-style', style);
  try {
    localStorage.setItem(KEY, style);
  } catch {
    /* выбор не сохранится между визитами, но применится сейчас */
  }
  for (const btn of document.querySelectorAll('[data-style-set]')) {
    btn.setAttribute('aria-checked', String(btn.dataset.styleSet === style));
  }
}

export function installStyleSwitch() {
  apply(currentStyle());
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-style-set]');
    if (!btn) return;
    apply(btn.dataset.styleSet);
  });
}
