/** Всплывающее уведомление в правом нижнем углу. */
let timer;

export function toast(message, { error = false, ms = 4500 } = {}) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = message;
  el.classList.toggle('toast--error', error);
  el.classList.add('is-shown');
  clearTimeout(timer);
  timer = setTimeout(() => el.classList.remove('is-shown'), ms);
}

export const toastError = (err) => toast(err?.message || String(err), { error: true });
