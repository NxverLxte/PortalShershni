/**
 * Общая обработка действий через data-атрибуты — представлениям не нужно
 * вешать обработчики вручную.
 *
 *   <form data-action="case.add" data-success="Заявление зарегистрировано">  — отправка формы
 *   <select data-action="case.status" data-id="…" name="status">             — смена статуса
 *   <button data-action="decree.delete" data-id="…" data-confirm="…">        — действие (с подтверждением)
 *   <button data-edit="case.decision" data-id="…" data-value="…">            — поле ввода под кнопкой
 */
import { act, logout } from '../store.js';
import { toast, toastError } from './toast.js';
import { formData } from '../utils.js';

const RESERVED = new Set(['action', 'confirm', 'success', 'edit', 'kind', 'field', 'value', 'placeholder', 'armed', 'keep']);

/** Параметры действия из data-атрибутов элемента. */
function params(el) {
  const out = {};
  for (const [k, v] of Object.entries(el.dataset)) if (!RESERVED.has(k)) out[k] = v;
  return out;
}

/** Сообщение об ошибке прямо в форме, над кнопкой отправки. Пустое сообщение убирает его. */
export function formError(form, message) {
  let el = form.querySelector(':scope > .form-error, .form-error');
  if (!message) {
    el?.remove();
    return;
  }
  if (!el) {
    el = document.createElement('div');
    el.className = 'form-error';
    el.setAttribute('role', 'alert');
    const submit = form.querySelector('button[type=submit], button:not([type])');
    if (submit && submit.parentElement === form) submit.before(el);
    else form.append(el);
  }
  el.textContent = message;
}

async function run(action, { success, busy, form } = {}) {
  if (busy) busy.disabled = true;
  if (form) formError(form, '');
  try {
    await act(action);
    if (success) toast(success);
    return true;
  } catch (err) {
    if (form && form.isConnected) formError(form, err.message);
    else toastError(err);
    return false;
  } finally {
    if (busy && busy.isConnected) busy.disabled = false;
  }
}

/** Двухшаговое подтверждение: первый щелчок меняет надпись, второй выполняет. */
function confirmed(button) {
  if (!button.dataset.confirm || button.dataset.armed) return true;
  const original = button.textContent;
  button.dataset.armed = '1';
  button.textContent = button.dataset.confirm;
  setTimeout(() => {
    if (!button.isConnected) return;
    delete button.dataset.armed;
    button.textContent = original;
  }, 3000);
  return false;
}

function openEditor(button) {
  const holder = button.closest('.controls') || button.parentElement;
  if (holder.querySelector('.editor')) return holder.querySelector('.editor textarea, .editor input')?.focus();
  const { kind, field, value, placeholder } = button.dataset;
  const editor = document.createElement('div');
  editor.className = 'editor';
  const input = document.createElement(kind === 'textarea' ? 'textarea' : 'input');
  if (kind === 'password') {
    input.type = 'text';
    input.minLength = 6;
    input.autocomplete = 'off';
  }
  input.value = value || '';
  input.placeholder = placeholder || '';
  const row = document.createElement('div');
  row.className = 'btn-row';
  row.innerHTML = '<button type="button" class="btn--sm">Сохранить</button><button type="button" class="btn--ghost btn--sm">Отмена</button>';
  const [save, cancel] = row.querySelectorAll('button');
  save.addEventListener('click', async () => {
    const ok = await run({ type: button.dataset.edit, ...params(button), [field]: input.value }, { success: 'Сохранено', busy: save });
    if (ok && editor.isConnected) editor.remove();
  });
  cancel.addEventListener('click', () => editor.remove());
  editor.append(input, row);
  holder.append(editor);
  input.focus();
}

/** Открыт ли сейчас какой-либо редактор или заполняется форма — тогда фоновое обновление не мешает. */
export const isBusy = () =>
  Boolean(document.querySelector('.editor')) || Boolean(document.activeElement?.matches('input, textarea, select'));

export function installInteractions() {
  document.addEventListener('submit', async (e) => {
    const form = e.target.closest('form[data-action]');
    if (!form) return;
    e.preventDefault();
    const ok = await run(
      { type: form.dataset.action, ...params(form), ...formData(form) },
      { success: form.dataset.success || 'Документ зарегистрирован', busy: form.querySelector('[type=submit], button:not([type])'), form },
    );
    if (ok && !('keep' in form.dataset)) form.reset();
  });

  // Ошибка под формой исчезает, как только пользователь начинает исправлять ввод
  document.addEventListener('input', (e) => {
    const form = e.target.closest?.('form');
    if (form) form.querySelector('.form-error')?.remove();
  });

  document.addEventListener('change', (e) => {
    const select = e.target.closest('select[data-action]');
    if (!select || select.form?.dataset.action) return;
    run({ type: select.dataset.action, ...params(select), [select.name]: select.value }, { success: 'Изменения сохранены' });
  });

  document.addEventListener('click', async (e) => {
    const logoutBtn = e.target.closest('[data-logout]');
    if (logoutBtn) {
      try {
        await logout();
        location.hash = 'glavnaya';
      } catch (err) {
        toastError(err);
      }
      return;
    }

    const editBtn = e.target.closest('button[data-edit]');
    if (editBtn) return openEditor(editBtn);

    const btn = e.target.closest('button[data-action]');
    if (!btn || btn.closest('form[data-action]')) return;
    if (!confirmed(btn)) return;
    run({ type: btn.dataset.action, ...params(btn) }, { success: btn.dataset.success || 'Выполнено', busy: btn });
  });
}
