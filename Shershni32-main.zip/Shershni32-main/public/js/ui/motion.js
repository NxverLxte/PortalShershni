/**
 * Анимации, которым нужен JavaScript:
 *  - появление блоков при прокрутке (класс .reveal → .is-visible, стили в css/motion.css);
 *  - плавный счёт чисел в сводке на главной.
 * Запускаются один раз при открытии раздела. Блоки, которые появляются позже
 * (при фоновом обновлении), показываются сразу — без повторной анимации.
 */
const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const REVEAL = [
  '.section-head',
  '.now-card',
  '.profile',
  '.profile-stats',
  '.sec-title',
  '.doc',
  '.service',
  '.organ',
  '.chapter h3',
  '.ballot',
  '.spy-lobby',
  '.rules li',
  '.wordlist',
  '.cta > *',
  '.empty',
  '.table-wrap',
].join(',');

let observer;
function getObserver() {
  observer ||= new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        e.target.classList.add('is-visible');
        observer.unobserve(e.target);
      }
    },
    { rootMargin: '0px 0px -8% 0px', threshold: 0.08 },
  );
  return observer;
}

/** Помечает блоки раздела для появления; соседние появляются с небольшим сдвигом по времени. */
export function revealIn(root) {
  if (reduced() || !('IntersectionObserver' in window)) return;
  const io = getObserver();
  const order = new Map();
  for (const el of root.querySelectorAll(REVEAL)) {
    if (el.closest('.hero')) continue;
    const i = order.get(el.parentElement) || 0;
    order.set(el.parentElement, i + 1);
    el.style.setProperty('--delay', `${Math.min(i, 6) * 70}ms`);
    el.classList.add('reveal');
    io.observe(el);
  }
}

/** Плавный счёт от нуля до значения у чисел в сводке. */
export function countUp(root, selector = '.stats strong') {
  if (reduced()) return;
  for (const el of root.querySelectorAll(selector)) {
    const target = Number(el.textContent);
    if (!Number.isFinite(target) || target <= 0 || el.textContent.trim() === '') continue;
    const duration = 1200;
    const start = performance.now() + 700; // после появления сводки
    el.textContent = '0';
    const tick = (now) => {
      const t = Math.min(1, Math.max(0, (now - start) / duration));
      const eased = 1 - (1 - t) ** 4;
      el.textContent = String(Math.round(target * eased));
      if (t < 1 && el.isConnected) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }
}

/** Всё, что делается при открытии раздела. */
export function animateEnter(root) {
  revealIn(root);
  countUp(root);
}
