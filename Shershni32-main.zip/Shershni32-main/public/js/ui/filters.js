/**
 * Фильтры реестров: вкладки по статусу (с количеством) и поиск по тексту.
 *
 *   mount:  `${filterShell('Поиск по делам')}` + bindFilters(root, this)
 *   update: fill(root, 'tabs', filterTabs(STATUS_MAP, items, this.filter, (x) => x.status))
 *           const shown = applyFilter(items, this.filter, { status: (x) => x.status, text: (x) => x.title })
 */
import { getState } from '../store.js';
import { esc } from '../utils.js';

export const newFilter = () => ({ status: 'all', q: '' });

export const filterShell = (placeholder = 'Поиск') => `
  <div class="filters">
    <div class="filter-tabs" role="tablist" data-region="tabs"></div>
    <label class="filter-search"><span class="sr-only">${esc(placeholder)}</span>
      <input type="search" data-filter-q placeholder="${esc(placeholder)}" autocomplete="off">
    </label>
  </div>`;

/** Вкладки: «Все» и статусы, которые реально встречаются в списке. */
export function filterTabs(map, items, filter, statusOf = (x) => x.status) {
  const counts = new Map();
  for (const x of items) counts.set(statusOf(x), (counts.get(statusOf(x)) || 0) + 1);
  const entries = Object.entries(map).filter(([k]) => counts.has(k));
  if (entries.length < 2) return '';
  const tab = (key, label, n) =>
    `<button type="button" role="tab" class="filter-tab" data-filter-status="${esc(key)}" aria-selected="${filter.status === key}">${esc(label)}<span>${n}</span></button>`;
  return tab('all', 'Все', items.length) + entries.map(([k, label]) => tab(k, label, counts.get(k))).join('');
}

export function applyFilter(items, filter, { status = (x) => x.status, text = () => '' } = {}) {
  const q = filter.q.trim().toLowerCase();
  return items.filter((x) => (filter.status === 'all' || status(x) === filter.status) && (!q || text(x).toLowerCase().includes(q)));
}

export const isFiltered = (filter) => filter.status !== 'all' || Boolean(filter.q.trim());

/** Подключает обработчики к разделу; при изменении фильтра раздел перерисовывается. */
export function bindFilters(root, view) {
  view.filter = newFilter();
  const rerender = () => {
    const state = getState();
    if (state) view.update(root, state);
  };
  root.addEventListener('click', (e) => {
    const tab = e.target.closest('[data-filter-status]');
    if (!tab || !root.contains(tab)) return;
    view.filter.status = tab.dataset.filterStatus;
    rerender();
  });
  root.addEventListener('input', (e) => {
    if (!e.target.matches('[data-filter-q]')) return;
    view.filter.q = e.target.value;
    rerender();
  });
}
