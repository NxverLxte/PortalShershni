/** Работа с областями страницы. */
import { can, me } from '../store.js';

const rendered = new WeakMap();

/**
 * Заменяет содержимое области <… data-region="name">, если изменилась разметка.
 * Сравнивается исходная строка, а не DOM, поэтому неизменившаяся область не
 * перерисовывается при каждом фоновом обновлении (сохраняются ввод и раскрытые блоки).
 */
export function fill(root, name, html) {
  const el = root.querySelector(`[data-region="${name}"]`);
  if (!el || rendered.get(el) === html) return;
  rendered.set(el, html);
  el.innerHTML = html;
}

export const setText = (root, name, text) => {
  const el = root.querySelector(`[data-region="${name}"]`);
  if (el) el.textContent = text;
};

/**
 * Показывает и скрывает элементы по правам:
 *   data-perm="decree.manage" — только при наличии полномочия
 *   data-auth="me"            — только вошедшим
 *   data-auth="guest"         — только гостям
 */
export function applyAccess(root) {
  for (const el of root.querySelectorAll('[data-perm]')) el.hidden = !can(el.dataset.perm);
  for (const el of root.querySelectorAll('[data-auth]')) el.hidden = el.dataset.auth === 'me' ? !me() : Boolean(me());
}

/** Заполняет выпадающий список, сохраняя выбранное значение. */
export function fillSelect(root, name, optionsHtml) {
  for (const select of root.querySelectorAll(`select[data-options="${name}"]`)) {
    const value = select.value;
    select.innerHTML = optionsHtml;
    if (value && [...select.options].some((o) => o.value === value)) select.value = value;
  }
}
