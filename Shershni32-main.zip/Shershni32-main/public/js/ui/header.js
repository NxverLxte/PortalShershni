/** Шапка: основная навигация, меню-шторка со всеми разделами, блок пользователя. */
import { ROLES } from '../../core/constants.js';
import { esc, initial, formatToday } from '../utils.js';
import { can } from '../store.js';

const $ = (id) => document.getElementById(id);
let routes = [];

/** Ссылки в шапке (primary) и полный список в меню. */
export function renderNav(list) {
  routes = list;
  $('nav').innerHTML = list
    .filter((r) => r.primary)
    .map((r) => `<a href="#${r.id}">${esc(r.title)}</a>`)
    .join('');
  renderMenuLinks(null);
}

function renderMenuLinks(state) {
  const items = routes.filter((r) => r.nav);
  if (state?.me) items.push(routes.find((r) => r.id === 'kabinet'));
  if (state?.me && can('users.manage')) items.push(routes.find((r) => r.id === 'admin'));
  $('menu-links').innerHTML = items.filter(Boolean).map((r, i) => `<a href="#${r.id}" style="--i:${i}">${esc(r.title)}</a>`).join('');
}

export function markActive(id) {
  for (const a of document.querySelectorAll('#nav a, #menu-links a, #tabbar a')) {
    if (a.getAttribute('href') === `#${id}`) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  }
}

export function renderUser(state) {
  const me = state?.me;
  $('ubox').innerHTML = me
    ? `<a class="ubox__who" href="#kabinet" style="text-decoration:none;color:inherit" aria-label="Личный кабинет">
         <span class="monogram" aria-hidden="true">${esc(initial(me.nick))}</span>
         <div><b>${esc(me.nick)}</b><small>${esc(ROLES[me.role] || '')}</small></div>
       </a>`
    : `<a class="btn btn--ghost btn--sm hide-sm" href="#vhod">Вход</a>
       <a class="btn btn--sm" href="#vhod" data-register>Гражданство</a>`;

  $('menu-account').innerHTML = me
    ? `<button type="button" class="btn--ghost" data-logout style="width:100%">Выйти</button>`
    : `<a class="btn" href="#vhod" data-register style="width:100%">Получить гражданство</a>
       <a class="btn btn--ghost" href="#vhod" style="width:100%">Вход</a>`;
  renderMenuLinks(state);
}

export function renderDates() {
  $('today').textContent = formatToday();
  $('year').textContent = new Date().getFullYear();
}

/* --- Меню-шторка и прозрачная шапка --- */

function setMenu(open) {
  document.body.classList.toggle('menu-open', open);
  $('menu-btn').setAttribute('aria-expanded', String(open));
  $('menu-btn').setAttribute('aria-label', open ? 'Закрыть меню' : 'Меню');
  updateSolid();
}

function updateSolid() {
  $('header').classList.toggle('is-solid', window.scrollY > 24 || document.body.classList.contains('menu-open'));
}

/** Шапка прячется при прокрутке вниз и плавно возвращается при прокрутке вверх. */
let lastY = 0;
function onScroll() {
  const y = window.scrollY;
  const header = $('header');
  const menuOpen = document.body.classList.contains('menu-open');
  if (menuOpen || y < 160 || y < lastY - 4) header.classList.remove('is-hidden');
  else if (y > lastY + 4) header.classList.add('is-hidden');
  lastY = y;
  updateSolid();
}

export function installHeader() {
  $('menu-btn').addEventListener('click', () => setMenu(!document.body.classList.contains('menu-open')));
  document.querySelector('[data-open-menu]')?.addEventListener('click', () => setMenu(!document.body.classList.contains('menu-open')));
  $('menu').addEventListener('click', (e) => {
    // Закрываем по щелчку на ссылку/кнопку или на затемнённый фон
    if (e.target.closest('[data-style-set]')) return; // переключатель оформления меню не закрывает
    if (e.target.closest('a, button') || !e.target.closest('.menu__panel')) setMenu(false);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') setMenu(false);
  });
  window.addEventListener('hashchange', () => setMenu(false));
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('hashchange', () => $('header').classList.remove('is-hidden'));
  updateSolid();
}
