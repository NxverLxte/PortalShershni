/**
 * Люди на портале: аватар с инициалом, строка «аватар + имя + подпись»,
 * значок звания и прогресс до следующего звания.
 */
import { ROLES, RANKS, rankOf } from '../../core/constants.js';
import { esc, initial } from '../utils.js';

/** Оттенок фона аватара — стабильный для одного и того же имени. */
function hue(name) {
  let h = 0;
  for (const ch of String(name)) h = (h * 31 + ch.codePointAt(0)) >>> 0;
  return 205 + (h % 40); // синие оттенки: 205–245
}

export function avatar(nick, { role = 'citizen', agent = false, size = 'md' } = {}) {
  const cls = ['avatar', `avatar--${size}`];
  if (role && role !== 'citizen') cls.push('avatar--official');
  if (agent) cls.push('avatar--agent');
  return `<span class="${cls.join(' ')}" style="--h:${hue(nick)}" aria-hidden="true">${esc(initial(nick))}</span>`;
}

/** Аватар, имя и подпись (по умолчанию — должность). */
export function person(nick, { role = 'citizen', agent = false, sub, size = 'md' } = {}) {
  const caption = sub === undefined ? ROLES[role] || '' : sub;
  return `
    <span class="person">
      ${avatar(nick, { role, agent, size })}
      <span class="person__text"><b>${esc(nick)}</b>${caption ? `<small>${esc(caption)}</small>` : ''}</span>
    </span>`;
}

const RANK_STYLE = {
  'Почётный шершень': 'merit',
  Шершень: 'citizen',
  'Ненадёжный шершень': 'risk',
  Агент: 'agent',
};

const INSIGNIA = {
  merit: '<circle cx="12" cy="12" r="10"/><path d="M12 6.2l1.7 3.6 3.9.4-2.9 2.7.8 3.9L12 14.9l-3.5 1.9.8-3.9-2.9-2.7 3.9-.4z" class="fill"/>',
  honor: '<path d="M6 9.5l6-4 6 4M6 14.5l6-4 6 4M6 19.5l6-4 6 4"/>',
  citizen: '<path d="M6 13l6-4.5 6 4.5"/>',
  risk: '<path d="M12 4l9 16H3z"/><path d="M12 10v4M12 17v.5"/>',
  agent: '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>',
};

/** Значок звания с подписью. */
export function rankBadge(score = 0, { label = true } = {}) {
  const title = rankOf(score);
  const key = RANK_STYLE[title] || 'citizen';
  return `<span class="rank rank--${key}" title="${esc(title)}"><svg viewBox="0 0 24 24" aria-hidden="true">${INSIGNIA[key]}</svg>${label ? `<span>${esc(title)}</span>` : ''}</span>`;
}

/** Прогресс до следующего звания: { next, need, percent } или null на высшем звании. */
export function rankProgress(score = 0) {
  const ascending = [...RANKS].reverse().filter((r) => Number.isFinite(r.min));
  const next = ascending.find((r) => r.min > score);
  if (!next) return null;
  const prevMin = [...ascending].reverse().find((r) => r.min <= score)?.min ?? Math.min(score, 0) - 50;
  const span = next.min - prevMin || 1;
  return { next: next.title, need: next.min - score, percent: Math.max(4, Math.min(100, Math.round(((score - prevMin) / span) * 100))) };
}
