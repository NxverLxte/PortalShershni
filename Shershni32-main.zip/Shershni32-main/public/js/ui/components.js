/**
 * Строительные блоки разметки. Каждая функция возвращает HTML-строку.
 * Все пользовательские данные проходят через esc().
 */
import { BILL_STAGES, BILL_STATUS } from '../../core/constants.js';
import { esc, formatDate } from '../utils.js';

const GOOD = new Set(['accepted', 'decided', 'ok', 'approved', 'signed', 'passed']);
const BAD = new Set(['rejected', 'closed', 'no', 'blocked', 'veto']);

/** data-атрибуты из объекта: { id: 'x', uid: 'y' } → ' data-id="x" data-uid="y"'. */
export const dataAttrs = (params = {}) =>
  Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null)
    .map(([k, v]) => ` data-${k.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)}="${esc(v)}"`)
    .join('');

export const tag = (label, tone = '') => `<span class="tag${tone ? ` tag--${tone}` : ''}">${esc(label)}</span>`;

export const statusTag = (map, key) => tag(map[key] || key, GOOD.has(key) ? 'ok' : BAD.has(key) ? 'bad' : '');

export const empty = (text) => `<div class="empty">${text}</div>`;

/** Запись реестра: слева номер и дата, справа содержимое. */
export const docRow = ({ no, date, body }) => `
  <article class="doc">
    <div class="doc__no"><b>${no}</b>${date ? esc(typeof date === 'number' ? formatDate(date) : date) : ''}</div>
    <div>${body}</div>
  </article>`;

/** Поле документа с подписью; пустые значения не выводятся. */
export const field = (label, value, { gold = false } = {}) =>
  value ? `<div class="field${gold ? ' field--gold' : ''}"><span>${esc(label)}</span><p class="text">${esc(value)}</p></div>` : '';

export const meta = (...items) => `<div class="meta">${items.filter(Boolean).join('')}</div>`;
export const metaItem = (text) => (text ? `<span>${esc(text)}</span>` : '');

export const list = (items, render, emptyText) => (items?.length ? items.map(render).join('') : empty(emptyText));

/** Ход рассмотрения законопроекта стрелками. При вето и отклонении не показывается. */
export function steps(status) {
  if (!BILL_STAGES.includes(status)) return '';
  const reached = BILL_STAGES.indexOf(status);
  return `<div class="steps">${BILL_STAGES.map((k, i) => `<i class="${i <= reached ? 'is-done' : ''}">${BILL_STATUS[k]}</i>`).join('')}</div>`;
}

export const pageHead = ({ crumb, parent, title, lead, eyebrow, compact = false }) => `
  <div class="phead${compact ? ' phead--compact' : ''}"><div class="in phead__grid">
    <div>
      ${crumb ? `<div class="crumb"><a href="#glavnaya">Главная</a><span class="sep">/</span>${parent ? `<a href="${parent.href}">${esc(parent.label)}</a><span class="sep">/</span>` : ''}${esc(crumb)}</div>` : ''}
      ${eyebrow ? `<div class="eyebrow">${esc(eyebrow)}</div>` : ''}
      <h1>${esc(title)}</h1>
      ${lead ? `<p class="lead">${lead}</p>` : ''}
    </div>
    <div class="phead__aside" data-region="head"></div>
  </div></div>`;

/** Крупные цифры раздела в шапке: headStats([[3, 'дела в производстве'], ...]). */
export const headStats = (items) =>
  items
    .filter(Boolean)
    .map(([value, label, tone]) => `<div class="head-stat${tone ? ` head-stat--${tone}` : ''}"><b>${esc(value)}</b><span>${esc(label)}</span></div>`)
    .join('');

export const sectionTitle = (title, link) =>
  `<div class="sec-title"><h2>${esc(title)}</h2>${link ? `<a href="${link.href}">${esc(link.label)}</a>` : ''}</div>`;

export const options = (items, selected) =>
  items.map(([value, label]) => `<option value="${esc(value)}"${value === selected ? ' selected' : ''}>${esc(label)}</option>`).join('');

/* --- Элементы управления для должностных лиц --- */

export const controls = (...items) => {
  const html = items.filter(Boolean).join('');
  return html ? `<div class="controls">${html}</div>` : '';
};

/** Выпадающий список статуса: смена значения сразу отправляет действие. */
export function statusSelect(action, params, map, current, { allowed, name = 'status', label = 'Статус' } = {}) {
  const entries = Object.entries(map).filter(([k]) => !allowed || allowed.includes(k) || k === current);
  return `<select name="${name}" aria-label="${esc(label)}" data-action="${action}"${dataAttrs(params)}>${options(entries, current)}</select>`;
}

export function actionButton(label, action, params, { confirm, primary = false, danger = false } = {}) {
  const cls = primary ? '' : `btn--ghost btn--sm${danger ? ' btn--danger' : ''}`;
  return `<button type="button" class="${cls}" data-action="${action}"${dataAttrs(params)}${confirm ? ` data-confirm="${esc(confirm)}"` : ''}>${esc(label)}</button>`;
}

export const deleteButton = (action, params) => actionButton('Удалить', action, params, { confirm: 'Подтвердить удаление', danger: true });

/** Кнопка, открывающая поле ввода под собой (резолюция, решение суда, новый пароль). */
export function editButton(label, action, params, { value = '', kind = 'textarea', field = 'text', placeholder = '' } = {}) {
  return `<button type="button" class="btn--ghost btn--sm" data-edit="${action}" data-kind="${kind}" data-field="${field}" data-placeholder="${esc(placeholder)}" data-value="${esc(value)}"${dataAttrs(params)}>${esc(label)}</button>`;
}

/** Таблица, которая на телефоне превращается в карточки. */
export function table(columns, rows, { className = '' } = {}) {
  const head = columns.map((c) => `<th${c.num ? ' class="num"' : ''}>${esc(c.label)}</th>`).join('');
  const body = rows
    .map((cells) => `<tr>${cells.map((cell, i) => `<td data-label="${esc(columns[i].label)}"${columns[i].num ? ' class="num"' : ''}>${cell ?? ''}</td>`).join('')}</tr>`)
    .join('');
  return `<div class="table-wrap"><table class="stack ${className}"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}
